(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"120x600_car_atlas_P_1", frames: [[0,0,240,1200],[0,1338,220,181],[0,1521,256,78],[0,1202,322,134]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg3 = function() {
	this.initialize(ss["120x600_car_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.curve = function() {
	this.initialize(ss["120x600_car_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.logo1 = function() {
	this.initialize(ss["120x600_car_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.logo2 = function() {
	this.initialize(ss["120x600_car_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.tcs = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0A1482").s().p("AgEAEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQABABAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAgBgBg");
	this.shape.setTransform(78.75,390.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0A1482").s().p("AgJAkQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgFABgFQACgDADgDQADgDAFgCQAEgCAFAAQAEAAAFACQAEACACADIABAAIAAghIAIAAIAABJIgIAAIAAgHIgBAAQgCAEgFACQgEACgEAAQgFgBgEgBgAgFAAIgFACIgDAEIgBAHIABAHIADAFIAFADQADABACABQAEgBADgBIAFgDIADgFIABgHIgBgHIgDgEIgFgCQgDgCgEAAQgCAAgDACg");
	this.shape_1.setTransform(74.575,387.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_2.setTransform(69.275,388.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQAAABgBABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_3.setTransform(64.225,388.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_4.setTransform(60.825,387.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_5.setTransform(57.225,388.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0A1482").s().p("AgMAYIAAguIAJAAIAAAHIACgDIACgDIAFgBIADgBIAFABIgBAJIgCAAIgCAAQgGAAgDADQgDAEAAAGIAAAYg");
	this.shape_6.setTransform(53.15,388.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0A1482").s().p("AgEAjIAAhFIAJAAIAABFg");
	this.shape_7.setTransform(50.075,387.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0A1482").s().p("AgFAmIAAgmIgKAAIAAgIIAKAAIAAgKQAAgJADgFQADgFAJAAIADABIADAAIgBAIIgCgBIgDAAIgEABIgCACIgBADIAAAFIAAAKIAKAAIAAAIIgKAAIAAAmg");
	this.shape_8.setTransform(44.875,387.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0A1482").s().p("AgJAXQgEgCgEgEQgDgDgCgEQgCgFAAgFQAAgEACgEQACgFADgDQAEgEAEgBQAFgCAEAAQAFAAAFACQAEABADAEQAEADACAFQACAEAAAEQAAAFgCAFQgCAEgEADQgDAEgEACQgFABgFAAQgEAAgFgBgAgGgOIgEADIgDAFIgBAGIABAHIADAFIAEADQADABADAAQADAAADgBIAFgDIADgFIABgHIgBgGIgDgFIgFgDQgDgBgDAAQgDAAgDABg");
	this.shape_9.setTransform(40.625,388.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0A1482").s().p("AAJAlIgUgYIAAAYIgJAAIAAhJIAJAAIAAAuIATgTIALAAIgUAUIAWAag");
	this.shape_10.setTransform(33.25,387.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_11.setTransform(28.025,388.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQgBABAAABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_12.setTransform(22.975,388.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0A1482").s().p("AgXAjIAAhFIAXAAIAIABIAHAEQADACACADQABADAAAFQAAAGgDADQgEAEgFACQADAAADABIAFAEIADAFIABAGQAAAFgCAEQgCADgDADQgDACgFABQgEACgFAAgAgNAbIANAAIAEgBIAEgCIAFgDQABgDAAgDQAAgGgEgDQgEgEgGAAIgNAAgAgNgFIAMAAIAEAAIAEgCIADgDIABgFQAAgEgDgDQgCgDgGAAIgNAAg");
	this.shape_13.setTransform(17.9,387.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_14.setTransform(11.225,387.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQAAABgBABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_15.setTransform(7.725,388.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#0A1482").s().p("AgNAYIAAguIAJAAIAAAHIADgDIACgDIAEgBIAFgBIADABIAAAJIgCAAIgCAAQgHAAgCADQgEAEAAAGIAAAYg");
	this.shape_16.setTransform(3.9,388.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIANAAIAAAHIgNAAIAAAUIAAAEIABAEIACACIADABIAEAAIADgBIAAAIIgEABg");
	this.shape_17.setTransform(0.15,388.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_18.setTransform(-3.875,388.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_19.setTransform(-9.025,388.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0A1482").s().p("AgJAhQgGgDgFgFQgFgFgCgHQgDgGAAgHQAAgHADgHQADgGAEgFQAFgFAGgDQAHgDAIABQAGgBAHADQAGACAEAGIgIAGQgCgDgEgDQgFgCgFAAQgFAAgFACQgFACgDAFQgDADgCAGQgCAFAAAEQAAAGACAFQACAFADADIAIAHQAFABAFABQAGgBAFgCQAEgCADgFIAIAGIgDADIgFAEIgHAEQgFABgGAAQgIAAgGgDg");
	this.shape_20.setTransform(-14.8,387.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_21.setTransform(80.825,377.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#0A1482").s().p("AAMAlIAAgcIgBgFIgCgEIgEgBIgEAAIgEABIgEABIgDAFIgBAHIAAAYIgJAAIAAhJIAJAAIAAAjQACgEAEgDQAEgBAFAAIAGABIAGACIADAGQACADAAAEIAAAeg");
	this.shape_22.setTransform(75.675,376.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIABACIAFABIADAAIADgBIAAAIIgEABg");
	this.shape_23.setTransform(71.2,377.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#0A1482").s().p("AgSAjIgDgBIABgJIAFACIAEgBIACgBIABgCIACgEIADgHIgTguIAKAAIAMAjIABAAIANgjIAKAAIgXA4IgBAFIgDAFIgFACIgFABg");
	this.shape_24.setTransform(64.95,379.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#0A1482").s().p("AgIAjQgEgBgDgEIAAAHIgJAAIAAhKIAJAAIAAAiQADgDAEgCQAFgCAEAAQAFAAAEACQAFABADAEQADADACAEQABAEABAGQgBAEgBAFQgCAFgDADQgDADgFACQgEACgFAAQgEAAgFgDgAgGgBIgEADIgEAEIgBAIIABAGIAEAFIAEADQADABADABQAEgBACgBIAFgDIADgFIABgGIgBgIIgDgEIgFgDQgCgBgEAAQgDAAgDABg");
	this.shape_25.setTransform(59.9,376.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#0A1482").s().p("AgJAkQgFgCgDgDQgDgDgCgFQgBgFAAgEQAAgGABgEQACgEADgDQADgEAFgBQAEgCAFAAQAEAAAFACQAEACACADIABAAIAAgiIAIAAIAABKIgIAAIAAgHIgBAAQgCAEgFABQgEADgEAAQgFAAgEgCgAgFgBIgFADIgDAEIgBAIIABAGIADAFIAFADQADABACABQAEgBADgBIAFgDIADgFIABgGIgBgIIgDgEIgFgDQgDgBgEAAQgCAAgDABg");
	this.shape_26.setTransform(51.525,376.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_27.setTransform(46.225,377.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgCgCABgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIABACIAEABIAEAAIADgBIAAAIIgEABg");
	this.shape_28.setTransform(41.75,377.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQgBABAAABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_29.setTransform(37.825,377.975);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_30.setTransform(34.425,376.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#0A1482").s().p("AgJAXIgGgDIgDgGQgCgDAAgFIAAgdIAJAAIAAAbIABAFQAAABABAAQAAABAAAAQAAABABAAQAAAAAAABIAEACIAEABIAEgBIAEgDIADgFIABgHIAAgXIAJAAIAAAuIgJAAIAAgHQgCADgEADQgEACgFAAIgGgBg");
	this.shape_31.setTransform(30.825,378.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#0A1482").s().p("AgMAhQgGgBgFgFIAGgHQAEADAEADQAEACAFAAQAEgBADgBIAFgEQACgCABgDIABgGIAAgHIgBAAQgCAFgFACQgEABgEAAQgFABgEgCQgFgCgDgDIgFgHQgBgEAAgFQAAgFABgFIAFgHQADgEAFgCQAEgBAFAAQAEAAAEABQAFADACADIABAAIAAgGIAIAAIAAAsQAAAGgBAEIgFAIQgEADgFACQgEACgFAAQgHAAgFgDgAgFgZIgFADIgDAFIgBAHQAAAHAEADQAEAFAGgBQAHABAFgFQAEgDAAgHIgBgHIgDgFIgFgDQgDgBgEAAQgCAAgDABg");
	this.shape_32.setTransform(25.275,379.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_33.setTransform(19.975,377.975);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#0A1482").s().p("AgMAYIAAguIAJAAIAAAHIACgDIACgDIAFgBIADgBIAFABIgBAJIgCAAIgCAAQgHAAgCADQgEAEABAGIAAAYg");
	this.shape_34.setTransform(15.9,377.925);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#0A1482").s().p("AgKAXQgEgCgEgFIAHgFIAFAEQADABADAAIADAAIADgBIACgCIABgDIgBgDIgDgCIgDgBIgDgBIgFgBIgFgCIgDgEQgBgCAAgDQAAgEABgCIAEgFIAGgDIAGAAIAJABQAEACACAEIgGAFIgFgDQgCgBgDAAQgCAAgCABQgBABgBAAQAAAAAAABQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIACACIAEACIADAAIAGACIADACIADADIACAGQAAAEgCADIgEAEIgHADIgGAAQgFAAgFgBg");
	this.shape_35.setTransform(9.45,377.975);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_36.setTransform(6.425,376.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_37.setTransform(0.375,377.925);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#0A1482").s().p("AgJAXQgEgCgEgEQgDgDgCgEQgCgFAAgFQAAgEACgEQACgFADgDQAEgEAEgBQAFgCAEAAQAFAAAFACQAEABADAEQAEADACAFQACAEAAAEQAAAFgCAFQgCAEgEADQgDAEgEACQgFABgFAAQgEAAgFgBgAgGgOIgEADIgDAFIgBAGIABAHIADAFIAEADQADABADAAQADAAADgBIAFgDIADgFIABgHIgBgGIgDgFIgFgDQgDgBgDAAQgDAAgDABg");
	this.shape_38.setTransform(-4.975,377.975);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_39.setTransform(-8.825,376.825);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_40.setTransform(-12.425,377.925);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#0A1482").s().p("AgKAiQgEgCgEgEQgEgEgCgFQgCgFAAgGIAAgrIAJAAIAAAqIABAHIAEAGIAFAFQADACAEAAQAFAAADgCIAGgFIACgGIABgHIAAgqIAKAAIAAArQAAAGgCAFQgDAFgDAEQgDAEgGACQgFACgFAAQgFAAgFgCg");
	this.shape_41.setTransform(-18.3,376.925);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIANAAIAAAHIgNAAIAAAUIAAAEIABAEIACACIADABIAEAAIADgBIAAAIIgEABg");
	this.shape_42.setTransform(71.7,366.375);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_43.setTransform(69.175,365.825);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#0A1482").s().p("AgJAkQgFgCgDgDQgDgEgCgEQgBgFAAgEQAAgGABgEQACgEADgDQADgDAFgCQAEgCAFAAQAEAAAFACQAEACACAEIABAAIAAgjIAIAAIAABJIgIAAIAAgGIgBAAQgCADgFACQgEACgEAAQgFAAgEgBgAgFgBIgFACIgDAFIgBAIIABAGIADAFIAFADQADACACAAQAEAAADgCIAFgDIADgFIABgGIgBgIIgDgFIgFgCQgDgBgEAAQgCAAgDABg");
	this.shape_44.setTransform(65.175,365.65);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_45.setTransform(59.875,366.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#0A1482").s().p("AgMAYIAAguIAIAAIAAAHIADgDIADgDIADgBIAFgBIADABIAAAJIgCAAIgCAAQgGAAgDADQgDAEgBAGIAAAYg");
	this.shape_46.setTransform(55.8,366.925);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#0A1482").s().p("AgJAhQgHgDgFgFQgEgFgDgHQgCgGAAgGQAAgIADgGQACgHAFgFQAFgFAGgDQAHgDAHAAQAHAAAHADQAGADAFAFIgIAGQgDgDgEgDQgFgCgFAAQgFAAgEADQgFACgEADQgDAEgCAFQgCAGAAAFQAAAFACAFQACAFADAEIAIAFQAFACAFABQAGAAAEgDQAFgDADgEIAIAGIgCADIgGAEIgIADQgEACgGABQgIAAgGgEg");
	this.shape_47.setTransform(50.75,365.85);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIACACIADABIAEAAIADgBIAAAIIgEABg");
	this.shape_48.setTransform(43,366.375);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#0A1482").s().p("AgKAXQgEgCgEgFIAIgFIAEAEQADABADAAIADAAIADgBIACgCIABgDIgBgDIgDgCIgEgBIgCgBIgGgBIgEgCIgDgEQgCgCAAgDQAAgEACgCIAEgFIAGgDIAFAAIAJABQAEACADAEIgHAFIgEgDQgCgBgDAAQgCAAgCABQgBABgBAAQAAAAAAABQgBAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIACACIADACIAEAAIAFACIAFACIACADIABAGQAAAEgBADIgEAEIgHADIgGAAQgFAAgFgBg");
	this.shape_49.setTransform(39.4,366.975);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#0A1482").s().p("AgNAYIAAguIAJAAIAAAHIADgDIACgDIAFgBIADgBIAEABIAAAJIgCAAIgCAAQgGAAgDADQgEAEAAAGIAAAYg");
	this.shape_50.setTransform(35.95,366.925);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_51.setTransform(33.025,365.825);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#0A1482").s().p("AgVAjIAAhFIArAAIAAAJIghAAIAAAWIAeAAIAAAIIgeAAIAAAeg");
	this.shape_52.setTransform(29.575,365.825);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#0A1482").s().p("AgNAYIAAguIAJAAIAAAHIADgDIADgDIADgBIAFgBIADABIAAAJIgCAAIgCAAQgHAAgCADQgDAEgBAGIAAAYg");
	this.shape_53.setTransform(22.7,366.925);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_54.setTransform(18.275,366.975);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#0A1482").s().p("AgIAjQgEgCgCgDIAAAGIgJAAIAAhJIAJAAIAAAjQACgEAEgCQAFgCAEAAQAFAAAFACQAEACADADQADADACAEQACAEgBAGQABAEgCAFQgCAEgDAEQgDADgEACQgFABgFAAQgEAAgFgCgAgFgBIgGACIgCAFIgBAIIABAGIACAFIAGADQACACADAAQADAAADgCIAFgDIADgFIABgGIgBgIIgDgFIgFgCQgDgBgDAAQgDAAgCABg");
	this.shape_55.setTransform(12.95,365.65);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#0A1482").s().p("AAaAYIAAgZIAAgFQAAgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBgBIgDgDIgFgBQgGAAgDAEQgDAEAAAGIAAAZIgHAAIAAgYIgBgGIgBgEIgDgEIgFgBIgFABIgEADIgCAFIgBAGIAAAYIgJAAIAAguIAIAAIAAAIIACgDIADgDIAFgCIAFgBQAFAAAEACQADACACAFQACgFAEgCQAEgCAEAAQAGAAADACQAEACACADQACACAAAEIABAIIAAAag");
	this.shape_56.setTransform(5.975,366.925);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_57.setTransform(-0.625,366.975);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#0A1482").s().p("AAbAjIAAg4IgYA4IgFAAIgXg4IgBAAIAAA4IgJAAIAAhFIAOAAIAVA0IAWg0IAOAAIAABFg");
	this.shape_58.setTransform(-7.525,365.825);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#0A1482").s().p("AgEAEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQABAAABAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAABAAQAAAAABABQAAAAAAAAQABABAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAgBgBg");
	this.shape_59.setTransform(55,357.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#0A1482").s().p("AgSAjIgDgBIABgIIAFABIAEgBIACgBIABgDIACgDIADgHIgTguIAKAAIAMAjIABAAIANgjIAKAAIgXA3IgBAGIgDAEIgFADIgFABg");
	this.shape_60.setTransform(51.45,357.15);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_61.setTransform(48.075,354.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#0A1482").s().p("AgYAmIAAhKIAKAAIAAAHQACgEAFgBQAEgDAEAAQAFAAAFADQAEABADADIAFAIQABAFAAAFQAAAFgBAEQgCAEgDADQgDADgEADQgFABgFAAQgEAAgEgCQgFgCgCgDIAAAigAgGgbIgFADIgDAFIAAAHIAAAHIADAEIAFADQADABADAAQADAAADgBIAFgDIADgEIABgHIgBgHIgDgFIgFgDQgDgBgDgBQgDABgDABg");
	this.shape_62.setTransform(44.3,357.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#0A1482").s().p("AgXAmIAAhKIAJAAIAAAHQACgEAEgBQAFgDAEAAQAFAAAFADQAEABADADIAFAIQACAFgBAFQABAFgCAEQgCAEgDADQgDADgEADQgFABgFAAQgEAAgFgCQgEgCgCgDIAAAigAgFgbIgGADIgCAFIgBAHIABAHIACAEIAGADQACABADAAQADAAADgBIAFgDIADgEIABgHIgBgHIgDgFIgFgDQgDgBgDgBQgDABgCABg");
	this.shape_63.setTransform(38.6,357.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQAAABgBABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_64.setTransform(33.175,355.975);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#0A1482").s().p("AgKAXQgEgCgEgFIAIgFIAEAEQADABADAAIADAAIADgBIACgCIABgDIgBgDIgDgCIgEgBIgCgBIgGgBIgEgCIgDgEQgCgCAAgDQAAgEACgCIAEgFIAGgDIAFAAIAJABQAEACADAEIgHAFIgDgDQgDgBgDAAQgCAAgCABQgBABgBAAQAAAAAAABQgBAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIADACIACACIAEAAIAFACIAFACIACADIABAGQABAEgCADIgEAEIgGADIgHAAQgFAAgFgBg");
	this.shape_65.setTransform(26.25,355.975);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#0A1482").s().p("AgJAhQgGgDgFgFQgFgFgCgGQgDgHAAgHQAAgGADgHQADgHAEgFQAFgFAHgDQAGgCAIgBQAGABAHACQAGACAEAGIgIAGQgCgEgEgCQgFgCgFAAQgFAAgFACQgFADgDADQgDAEgCAFQgCAFAAAFQAAAGACAFQABAEAEAEIAIAGQAFACAFAAQAGAAAFgCQAEgDADgEIAIAGIgDADIgFAEIgHADQgFACgGAAQgIABgGgEg");
	this.shape_66.setTransform(21.1,354.85);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#0A1482").s().p("AgTAiQgEgBgDgDIgEgHQgCgDAAgEQAAgEACgDQABgDACgCIAFgEIAGgDIgGgHQgCgEAAgFQAAgEACgDQABgDADgCIAFgDIAIgBIAFABIAGADIAEAFIABAGIgBAGIgDAFIgFAEIgEADIANAOIAJgOIAKAAIgNAUIAQAQIgNAAIgJgJQgEAFgFADQgEADgHAAQgGAAgEgCgAgOAEIgEADIgDAEIgBAFIABAEIADAEIAFADIAEABIAFgBIAEgCIADgDIADgDIgQgRgAgMgZQgDACAAAEIABADIACADIACADIACADIAEgDIADgCIACgDIABgFQAAgDgCgCQgCgCgDAAQgEAAgDACg");
	this.shape_67.setTransform(14.475,354.875);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#0A1482").s().p("AgEAjIAAg8IgWAAIAAgJIA1AAIAAAJIgWAAIAAA8g");
	this.shape_68.setTransform(8.2,354.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tcs, new cjs.Rectangle(-25,346.5,111.6,50.39999999999998), null);


(lib.logo2_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo2();
	this.instance.setTransform(-125,292,0.3442,0.3442);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo2_mc, new cjs.Rectangle(-125,292,110.9,46.10000000000002), null);


(lib.logo1_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo1();
	this.instance.setTransform(-151,328,0.3828,0.3828);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo1_mc, new cjs.Rectangle(-151,328,98,29.899999999999977), null);


(lib.loans_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRAoQgJgEgFgJIAKgHQADAHAHAEQAHADAGAAIAHgBIAGgDQADgCABgDQACgCAAgEQAAgGgEgDQgDgDgGgBIgLgDQgGgBgFgCQgGgCgEgEQgDgFAAgIQAAgGACgEQADgFAEgDQAEgDAFgBQAFgCAEAAQAKAAAIAEQAHAEAFAIIgKAGQgDgGgFgDQgEgDgIAAIgFABIgGADIgEAEQgCACAAADQAAAGAEADIAJAEIALADQAHABAFACQAFACAEAEQAEAFAAAIQAAAHgDAEQgCAFgEADQgEAEgGABQgFACgGAAQgKAAgJgEg");
	this.shape.setTransform(84.325,8.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPApQgHgEgGgFQgGgGgDgIQgCgIAAgKQAAgIACgIQAEgIAFgGQAGgGAHgDQAIgEAIAAQAKAAAHAEQAHADAFAGQAFAFADAHQACAHAAAHIAAAHIhFAAIACAJQABAFAEAFQADAFAGAEQAGADAJAAQAIAAAIgEQAIgEAEgHIAIAHQgHAKgJAEQgJAEgLAAQgJAAgIgDgAAdgGQAAgFgCgFQgCgFgEgEQgEgEgFgCQgGgCgFAAQgIAAgGAEQgGADgDAFQgEAFgBAEIgCAGIA6AAIAAAAg");
	this.shape_1.setTransform(76.675,8.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggAqIAAgHIAwhCIguAAIAAgJIA9AAIAAAGIgxBCIAzAAIAAAKg");
	this.shape_2.setTransform(68.85,8.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgFA+IAAhSIALAAIAABSgAgFgwQgCgCAAgDQAAgDACgDQACgCADAAQAEAAACACQACADAAADQAAADgCACQgCADgEAAQgDAAgCgDg");
	this.shape_3.setTransform(63.85,6.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgRAoQgJgEgFgJIAKgHQADAHAHAEQAHADAGAAIAHgBIAGgDQADgCABgDQACgCAAgEQAAgGgEgDQgDgDgGgBIgLgDQgGgBgFgCQgGgCgEgEQgDgFAAgIQAAgGACgEQADgFAEgDQAEgDAFgBQAFgCAEAAQAKAAAIAEQAHAEAFAIIgKAGQgDgGgFgDQgEgDgIAAIgFABIgGADIgEAEQgCACAAADQAAAGAEADIAJAEIALADQAHABAFACQAFACAEAEQAEAFAAAIQAAAHgDAEQgCAFgEADQgEAEgGABQgFACgGAAQgKAAgJgEg");
	this.shape_4.setTransform(58.725,8.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgFBEIAAiHIAKAAIAACHg");
	this.shape_5.setTransform(50.25,6.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEBEIAAiHIAKAAIAACHg");
	this.shape_6.setTransform(46.95,6.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgPArQgFgCgEgDQgFgDgCgEQgDgFAAgHQAAgJAFgGQAFgEAHgDQAHgDAIgBIANgBIANAAIAAgFQAAgLgHgEQgHgFgJAAQgOAAgLAJIgHgHQAHgGAJgDQAIgDAIAAQAPAAAIAIQAJAHAAAPIAAAUIAAALIABAJIAAAIIABAHIgKAAIgBgOIgBAAQgEAIgHAEQgHAEgJAAIgLgBgAgBABIgLADQgFACgDAEQgDADAAAGQAAAEABACIAFAFIAGADIAHABQAIAAAFgCQAGgDADgEQADgEABgFIACgKIAAgGIgMAAg");
	this.shape_7.setTransform(41.05,8.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJBFIAAhIIgRAAIAAgKIARAAIAAgbQAAgIADgFQACgGADgDQADgDAEgCIAJgBQAHAAAFACIgCAKQgDgCgHAAQgOAAAAAWIAAAXIAUAAIAAAKIgUAAIAABIg");
	this.shape_8.setTransform(31.6,6.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRApQgIgEgGgFQgFgGgEgIQgDgIAAgKQAAgIADgIQAEgIAFgGQAGgGAIgDQAJgEAIAAQAJAAAJAEQAHADAGAGQAGAGADAIQAEAIAAAIQAAAKgEAIQgDAIgGAGQgGAFgHAEQgJADgJAAQgIAAgJgDgAgNgeQgGADgEAEQgFAFgBAGQgDAGAAAGQAAAHADAGQABAHAFAEQAEAFAGACQAHADAGAAQAIAAAFgDQAHgCAEgFQAEgEACgHQADgGAAgHQAAgGgDgGQgCgGgEgFQgEgEgHgDQgFgDgIAAQgGAAgHADg");
	this.shape_9.setTransform(24.25,8.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgRAoQgJgEgFgJIAKgHQADAHAHAEQAHADAGAAIAHgBIAGgDQADgCABgDQACgCAAgEQAAgGgEgDQgDgDgGgBIgLgDQgGgBgFgCQgGgCgEgEQgDgFAAgIQAAgGACgEQADgFAEgDQAEgDAFgBQAFgCAEAAQAKAAAIAEQAHAEAFAIIgKAGQgDgGgFgDQgEgDgIAAIgFABIgGADIgEAEQgCACAAADQAAAGAEADIAJAEIALADQAHABAFACQAFACAEAEQAEAFAAAIQAAAHgDAEQgCAFgEADQgEAEgGABQgFACgGAAQgKAAgJgEg");
	this.shape_10.setTransform(12.275,8.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAaArIAAgwIgBgKIgEgJQgCgDgEgDQgEgCgGAAQgGAAgFACQgFACgEAFQgEAEgCAGQgDAHAAAHIAAAqIgKAAIAAg7IgBgGIAAgGIAAgHIAAgEIALAAIAAAJIAAAFIABAAQAEgHAHgFQAIgFAJAAQAJAAAGADQAHAEADAEQADAFACAHIABANIAAAxg");
	this.shape_11.setTransform(4.55,8.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPArQgFgCgEgDQgEgDgDgEQgDgFAAgHQAAgJAFgGQAFgEAHgDQAHgDAIgBIANgBIANAAIAAgFQAAgLgHgEQgHgFgKAAQgNAAgLAJIgGgHQAFgGAKgDQAIgDAHAAQAQAAAIAIQAKAHgBAPIAAAUIAAALIABAJIAAAIIABAHIgKAAIgBgOIgBAAQgEAIgHAEQgHAEgJAAIgLgBgAgBABIgLADQgFACgDAEQgDADAAAGQAAAEACACIAEAFIAGADIAHABQAHAAAGgCQAFgDAEgEQADgEACgFIABgKIAAgGIgMAAg");
	this.shape_12.setTransform(-4.15,8.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgRApQgIgEgFgFQgHgGgCgIQgEgIAAgKQAAgIAEgIQACgIAHgGQAFgGAIgDQAJgEAIAAQAJAAAIAEQAJADAGAGQAFAGAEAIQADAIAAAIQAAAKgDAIQgEAIgFAGQgGAFgJAEQgIADgJAAQgIAAgJgDgAgMgeQgHADgEAEQgEAFgCAGQgDAGAAAGQAAAHADAGQACAHAEAEQAEAFAHACQAFADAHAAQAHAAAHgDQAGgCAEgFQAFgEABgHQADgGAAgHQAAgGgDgGQgBgGgFgFQgEgEgGgDQgHgDgHAAQgHAAgFADg");
	this.shape_13.setTransform(-13,8.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgFBEIAAiHIAKAAIAACHg");
	this.shape_14.setTransform(-19.5,6.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgUArIAAg7IAAgGIAAgGIgBgHIAAgEIALAAIAAAJIABAFQADgHAGgFQAHgFAJAAIADABIADAAIgBALIgEgBQgHAAgFADQgFACgDAEQgDAEgCAFQgCAFABAGIAAAtg");
	this.shape_15.setTransform(55.5,-8.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPArQgFgCgFgDQgEgDgCgEQgDgFAAgHQAAgJAFgGQAFgEAHgDQAHgDAIgBIANgBIANAAIAAgFQAAgLgHgEQgGgFgLAAQgNAAgLAJIgGgHQAGgGAIgDQAKgDAGAAQAPAAAKAIQAIAHABAPIAAAUIAAALIAAAJIABAIIAAAHIgKAAIgBgOIAAAAQgFAIgHAEQgHAEgKAAIgKgBgAAAABIgMADQgFACgDAEQgDADAAAGQAAAEACACIAEAFIAGADIAHABQAIAAAFgCQAFgDAEgEQADgEACgFIABgKIAAgGIgMAAg");
	this.shape_16.setTransform(48.2,-8.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKApQgJgEgFgFQgGgGgDgIQgDgIAAgKQAAgIADgIQADgIAGgGQAFgGAJgDQAIgEAIAAQAJAAAIAEQAIAEAGAHIgIAGQgFgFgGgDQgFgDgHAAQgGAAgGADQgHADgEAEQgEAFgCAGQgDAGAAAGQAAAHADAGQACAHAEAEQAEAFAHACQAGADAGAAQAHAAAGgDQAFgDAFgFIAIAHQgGAHgIADQgIAEgJAAQgIAAgIgDg");
	this.shape_17.setTransform(40.725,-8.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUArIAAg7IgBgGIAAgGIAAgHIAAgEIALAAIAAAJIAAAFQAFgHAFgFQAGgFAKAAIADABIADAAIgBALIgEgBQgHAAgFADQgFACgDAEQgDAEgCAFQgCAFAAAGIAAAtg");
	this.shape_18.setTransform(30.95,-8.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgRApQgIgEgFgFQgHgGgCgIQgEgIAAgKQAAgIAEgIQACgIAHgGQAFgGAIgDQAJgEAIAAQAKAAAHAEQAJADAGAGQAFAGAEAIQACAIAAAIQAAAKgCAIQgEAIgFAGQgGAFgJAEQgHADgKAAQgIAAgJgDgAgMgeQgHADgEAEQgEAFgCAGQgDAGAAAGQAAAHADAGQACAHAEAEQAEAFAHACQAFADAHAAQAHAAAHgDQAGgCAEgFQAEgEADgHQACgGAAgHQAAgGgCgGQgDgGgEgFQgEgEgGgDQgHgDgHAAQgHAAgFADg");
	this.shape_19.setTransform(23.1,-8.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AglBAIAAh/IBLAAIAAALIg/AAIAAAtIA7AAIAAAKIg7AAIAAA9g");
	this.shape_20.setTransform(14.325,-11.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.loans_mc, new cjs.Rectangle(-23.7,-24.6,113.10000000000001,46.2), null);


(lib.curve_inner_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.curve();
	this.instance.setTransform(-55,-90.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.curve_inner_mc, new cjs.Rectangle(-55,-90.5,110,90.5), null);


(lib.cta_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgpA8IAAh3IBQAAIAAAYIg2AAIAAAXIAzAAIAAAXIgzAAIAAAZIA5AAIAAAYg");
	this.shape.setTransform(42.075,7.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAQA8IgYgwIgMAAIAAAwIgbAAIAAh3IAvAAQAIAAAIACQAIABAGAFQAGAEAEAHQADAHABAKQgBANgGAJQgHAIgNACIAgAzgAgUgJIAPAAIAGgBQAFAAACgBQAEgBACgDQACgDAAgFQAAgEgBgDIgGgEIgGgCIgGgBIgRAAg");
	this.shape_1.setTransform(31.65,7.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpA8IAAh3IBQAAIAAAYIg2AAIAAAXIAzAAIAAAXIgzAAIAAAZIA5AAIAAAYg");
	this.shape_2.setTransform(20.625,7.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaA8IAAg0IgyAAIAAA0IgbAAIAAh3IAbAAIAAAtIAyAAIAAgtIAbAAIAAB3g");
	this.shape_3.setTransform(8.75,7.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AATA8Igwg5IAAA5IgaAAIAAh3IAaAAIAAAyIAugyIAiAAIg0A4IA5A/g");
	this.shape_4.setTransform(43.825,-9.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOA7QgMgFgJgIQgJgIgFgMQgEgLAAgPQAAgNAEgMQAFgMAJgIQAJgIAMgFQAMgEANAAIALABIAKADQAGACAEADIAJAIIgUARQgEgFgFgCQgHgDgHAAQgIAAgEADQgHADgFAFQgEAFgDAIQgCAHAAAHQAAAJACAHQADAHAEAFQAEAFAHADQAFADAHAAQAJAAAGgEQAGgDAEgGIAWAQQgIALgLAFQgMAFgMAAQgNAAgMgEg");
	this.shape_5.setTransform(31.5,-9.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgMA8IAAh3IAZAAIAAB3g");
	this.shape_6.setTransform(23.075,-9.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AglA8IAAh3IAbAAIAABfIAwAAIAAAYg");
	this.shape_7.setTransform(16.825,-9.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgPA7QgLgFgJgIQgJgIgEgMQgFgLAAgPQAAgNAFgMQAEgMAJgIQAJgIALgFQAMgEANAAIALABIALADQAGACAFADIAJAIIgVARQgEgFgGgCQgFgDgIAAQgHAAgGADQgGADgFAFQgFAFgCAIQgCAHgBAHQABAJACAHQACAHAFAFQAEAFAHADQAFADAIAAQAHAAAHgEQAGgDAEgGIAWAQQgIALgLAFQgMAFgNAAQgNAAgMgEg");
	this.shape_8.setTransform(6.35,-9.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_mc, new cjs.Rectangle(-4.1,-22.3,57.7,44.400000000000006), null);


(lib.copy1_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgHBPQgEgCgDgDIgEgGQgBgEAAgEIABgIIAEgGIAHgFIAHgBIAIABIAGAFIAEAGIACAIQAAAEgCAEIgEAGQgDADgDACIgIACIgHgCgAgQAcIAAgKQAAgHACgEQACgFAEgDIAKgLIAJgHIAGgIQACgDAAgEQAAgHgEgEQgFgFgHAAQgJAAgFAHQgGAFAAAIIgigCQACgYAPgMQAPgMAWABQAKgBAJADQAJADAGAFQAHAGAEAIQAEAIAAALQAAAGgBAFQgBAGgEAEQgDAFgFAFIgNALQgFAEgCADQgCAEAAAEIAAAHg");
	this.shape.setTransform(-13.225,57.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AglA3IAAhqIAhAAIAAARIABAAQAEgKAHgFQAIgFALAAIAFAAIAGABIAAAeIgHgBIgHgBQgKAAgFADQgGADgDAEQgCAFgBAHIgBANIAAAtg");
	this.shape_1.setTransform(-23.875,59.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbA2QgHgCgFgEQgFgEgDgHQgDgFAAgJQAAgJADgGQADgHAGgDQAGgEAIgDQAHgCAIgBIAPgBIAPAAQAAgKgGgFQgHgEgIgBQgHAAgHAEQgHAEgFAFIgSgSQAKgIAMgFQAMgEANAAQAOAAAJADQAKAEAFAHQAGAIACAJQACALAAANIAAA1IgeAAIAAgNQgGAJgJAEQgIADgKAAQgIAAgHgCgAADAHIgJACQgFABgEAEQgEADAAAFQAAAGAFADQAFACAGABIAIgBIAIgFQAEgCACgDQACgFAAgEIAAgHIgIAAg");
	this.shape_2.setTransform(-35.025,60);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMA0QgLgEgIgHQgIgHgEgLQgFgKAAgNQAAgLAFgLQAEgKAIgIQAIgHALgEQALgEAMAAQAJAAAKADQALADAIAIIgWAXQgDgDgEgDQgEgCgFAAQgMAAgHAHQgHAIAAALQAAAMAHAHQAHAIAMAAQAFAAAEgCIAHgGIAWAXQgIAHgLAEQgKADgJAAQgMAAgLgEg");
	this.shape_3.setTransform(-45.875,60);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAWA1IgWhGIAAAAIgTBGIgiAAIgnhqIAjAAIAWBDIABAAIAShDIAjAAIAUBDIAAAAIAUhDIAiAAIgmBqg");
	this.shape_4.setTransform(-67.625,60);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSA0QgLgEgIgHQgIgHgEgLQgFgKAAgNQAAgLAFgLQAEgKAIgIQAIgHALgEQALgEAMAAQALAAAJAEQAKAEAGAHQAHAIADAKQAEALAAALIAAAKIhMAAQACAKAHAFQAGAGAJAAQAIAAAGgEQAFgDAFgGIAXARQgIAKgMAGQgMAFgNAAQgMAAgLgEgAAWgLQAAgIgGgHQgGgFgJAAQgEAAgEACQgEABgDADQgDADgCADQgCAEAAAEIArAAIAAAAg");
	this.shape_5.setTransform(-83.275,60);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATA3IAAg1IAAgIIgCgJQgDgEgDgDQgDgDgGAAQgGAAgEADQgEACgCAEQgCAEAAAEIgBAJIAAA2IgiAAIAAhqIAhAAIAAAOIAAAAIAEgGIAHgFIAIgEQAFgCAGAAQAMAAAIAEQAIAEAEAHQAEAHACAJQABAJAAALIAAA6g");
	this.shape_6.setTransform(-96.1,59.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbA2QgHgCgFgEQgFgFgDgGQgDgFAAgJQAAgJADgGQADgHAGgDQAGgEAIgCQAHgDAIgBIAPgCIAPAAQAAgIgGgFQgHgGgIAAQgHABgHADQgHAEgFAFIgSgSQAKgJAMgEQAMgEANAAQAOAAAJADQAKAEAFAHQAGAHACAKQACAKAAAOIAAA2IgeAAIAAgOQgGAIgJAFQgIADgKAAQgIAAgHgCgAADAHIgJACQgFACgEACQgEADAAAGQAAAGAFADQAFADAGAAIAIgBIAIgFQAEgCACgEQACgDAAgGIAAgGIgIAAg");
	this.shape_7.setTransform(-30.975,35.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWA0QgLgEgIgHQgIgIgFgKQgEgKgBgNQABgLAEgLQAFgLAIgHQAIgHALgEQALgEALAAQAMAAAMAEQAKAEAIAHQAIAHAFALQAFALAAALQAAANgFAKQgFAKgIAIQgIAHgKAEQgMAEgMAAQgLAAgLgEgAgSgSQgIAHAAALQAAAMAIAHQAGAIAMAAQAMAAAHgIQAIgHgBgMQABgLgIgHQgHgIgMAAQgMAAgGAIg");
	this.shape_8.setTransform(-50.35,35.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AADBFQgGgCgFgDQgGgEgCgGQgDgHgBgJIAAgyIgVAAIAAgaIAVAAIAAggIAgAAIAAAgIAdAAIAAAaIgdAAIAAAjIABAIIACAHQACACADABQADACAFAAIAHAAQAEgBACgCIAAAbQgFACgGABIgLABQgJAAgHgCg");
	this.shape_9.setTransform(-61.9,34.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AATA3IAAg1IAAgIIgCgJQgDgEgDgDQgDgDgGAAQgGAAgEADQgEACgCAEQgCAEAAAEIgBAJIAAA2IgiAAIAAhqIAhAAIAAAOIAAAAIAEgGIAHgFIAIgEQAFgCAGAAQAMAAAIAEQAIAEAEAHQAEAHACAJQABAJAAALIAAA6g");
	this.shape_10.setTransform(-72.7,35.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgQBQIAAhqIAhAAIAABqgAgNguQgFgGAAgIQAAgIAFgFQAGgGAHAAQAIAAAFAGQAGAFAAAIQAAAIgGAGQgFAFgIAAQgHAAgGgFg");
	this.shape_11.setTransform(-82.05,33.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AADBFQgGgCgGgDQgEgFgDgFQgEgHAAgIIAAgzIgUAAIAAgaIAUAAIAAgfIAhAAIAAAfIAcAAIAAAaIgcAAIAAAjIAAAIIACAHQABACAEABQADACAFAAIAHgBQAEAAACgCIAAAbQgFACgGABIgLAAQgJAAgHgBg");
	this.shape_12.setTransform(-38.7,10.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgQBTIAAilIAhAAIAAClg");
	this.shape_13.setTransform(-46.05,8.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgSA0QgLgEgIgHQgIgHgEgLQgFgKAAgNQAAgMAFgKQAEgLAIgHQAIgHALgEQALgEAMAAQALAAAJAEQAKAEAGAHQAHAHADALQAEAKAAAMIAAALIhMAAQACAJAHAGQAGAFAJAAQAIAAAGgDQAFgEAFgGIAXARQgIAKgMAFQgMAGgNAAQgMAAgLgEgAAWgLQAAgJgGgFQgGgHgJAAQgEAAgEACQgEACgDADQgDADgCAEQgCADAAAEIArAAIAAAAg");
	this.shape_14.setTransform(-55.375,11.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgEBTIgKgEIgHgGIgFgFIgBAAIAAAOIgeAAIAAilIAhAAIAABHIAAAAQAGgIAJgEQAJgDAJAAQAMABAJAEQAJAFAGAIQAGAIAEAJQADAKAAALQAAAMgEALQgDAKgHAHQgHAIgKAEQgKADgLAAQgGAAgEgBgAgUAJQgHAHAAAMQAAAMAHAIQAHAHANAAQALAAAHgHQAHgIAAgMQAAgMgHgHQgHgIgLAAQgNAAgHAIg");
	this.shape_15.setTransform(-68.475,9.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgfBOQgOgDgLgKIASgbQAIAHAIADQAIAEALAAQAOAAAHgHQAHgIAAgLIAAgLIAAAAQgGAIgIADQgJAEgGAAQgMAAgKgFQgKgEgHgHQgHgHgDgJQgEgLAAgMQAAgKADgKQAEgKAGgIQAGgIAJgFQAJgEAMAAQAHAAAFABIAKAEIAIAGIAFAFIABAAIAAgOIAeAAIAABhQAAAfgPAPQgQAQgeAAQgOAAgOgDgAgIgxIgIAGQgEADgCAFQgCAFAAAFQAAAFACAFQACAFAEADQADAEAFACQAFACAEAAQAGAAAFgCQAFgCADgEQAEgDACgFQACgFAAgFQAAgFgCgFQgCgFgEgDQgDgEgFgCQgFgCgGAAQgEAAgFACg");
	this.shape_16.setTransform(-28.725,-9.625);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AASA3IAAg1IAAgIIgBgJQgCgEgEgDQgDgDgHAAQgFAAgEADQgEACgCAEQgCAEgBAEIgBAJIAAA2IghAAIAAhqIAhAAIAAAOIAAAAIAEgGIAHgFIAIgEQAFgCAGAAQAMAAAJAEQAHAEAEAHQAFAHABAJQABAJABALIAAA6g");
	this.shape_17.setTransform(-41.8,-12.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgQBQIAAhqIAgAAIAABqgAgMguQgGgGAAgIQAAgIAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAIQAAAIgFAGQgGAFgIAAQgHAAgFgFg");
	this.shape_18.setTransform(-51.15,-14.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAzA3IAAg+QAAgHgDgFQgDgGgJAAQgFAAgEACQgEACgCADQgCAEgCAEIgBAJIAAA4IggAAIAAg4IAAgHIgBgIQgBgDgDgDQgEgDgFAAQgGAAgEADQgFACgBAEQgCAEgBAEIgBAJIAAA2IghAAIAAhqIAgAAIAAAOIAAAAIAFgGIAHgFIAJgEQAEgCAHAAQALAAAIAFQAIAEAFAKQAGgKAHgEQAIgFAMAAQALAAAHAEQAIADAEAHQAEAGACAIQACAJAAAKIAAA+g");
	this.shape_19.setTransform(-63.75,-12.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgQBQIAAhqIAgAAIAABqgAgMguQgGgGAAgIQAAgIAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAIQAAAIgFAGQgGAFgIAAQgHAAgFgFg");
	this.shape_20.setTransform(-76.35,-14.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AADBFQgGgCgFgEQgGgDgCgHQgEgGAAgIIAAgzIgVAAIAAgaIAVAAIAAgfIAgAAIAAAfIAdAAIAAAaIgdAAIAAAjIABAIIACAHQACACADABQADACAFAAIAHgBQAEAAACgCIAAAcQgFACgGAAIgLAAQgJABgHgCg");
	this.shape_21.setTransform(-84.05,-13.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAWA1IgWhGIAAAAIgTBGIgiAAIgnhqIAjAAIAWBDIABAAIAShDIAjAAIAUBDIAAAAIAUhDIAiAAIgmBqg");
	this.shape_22.setTransform(-42.075,-36.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgSA0QgLgEgIgHQgIgHgEgLQgFgKAAgNQAAgLAFgLQAEgLAIgHQAIgHALgEQALgEAMAAQALAAAJAEQAKAEAGAHQAHAHADALQAEALAAALIAAAKIhMAAQACAKAHAFQAGAGAJAAQAIAAAGgEQAFgDAFgGIAXARQgIAKgMAGQgMAFgNAAQgMAAgLgEgAAWgLQAAgIgGgHQgGgFgJAAQgEAAgEACQgEABgDADQgDADgCADQgCAEAAAEIArAAIAAAAg");
	this.shape_23.setTransform(-57.725,-36.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AATA3IAAg1IAAgIIgDgJQgBgEgEgDQgDgDgGAAQgGAAgEADQgEACgCAEQgCAEAAAEIgBAJIAAA2IghAAIAAhqIAfAAIAAAOIABAAIAEgGIAHgFIAIgEQAFgCAGAAQANAAAHAEQAIAEAEAHQAEAHACAJQABAJAAALIAAA6g");
	this.shape_24.setTransform(-70.55,-36.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AADBFQgGgCgGgEQgFgEgDgFQgCgHAAgJIAAgxIgVAAIAAgbIAVAAIAAggIAgAAIAAAgIAdAAIAAAbIgdAAIAAAiIAAAIIACAGQABADADACQAEABAFAAIAHAAQAFgBACgCIAAAbQgGADgGAAIgMABQgIgBgHgBg");
	this.shape_25.setTransform(-38.1,-61.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgbA2QgHgCgFgEQgFgEgDgHQgDgFAAgJQAAgJADgGQADgHAGgDQAGgEAIgDQAHgCAIgBIAPgCIAPAAQAAgIgGgFQgHgFgIgBQgHAAgHAEQgHADgFAGIgSgSQAKgIAMgFQAMgEANAAQAOAAAJADQAKAEAFAHQAGAIACAJQACAKAAAOIAAA1IgeAAIAAgNQgGAJgJAEQgIADgKAAQgIAAgHgCgAADAHIgJACQgFABgEAEQgEADAAAFQAAAGAFADQAFACAGABIAIgBIAIgFQAEgCACgDQACgFAAgEIAAgHIgIAAg");
	this.shape_26.setTransform(-48.625,-60.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AATBTIAAg0IAAgKIgCgJQgCgEgEgDQgDgCgHAAQgFAAgEACQgEACgCAEQgCAEAAAFIgBAKIAAA1IgiAAIAAilIAiAAIAABKIAAAAQABgDADgDIAGgGIAIgEQAFgBAGAAQANAAAHAEQAIADAEAHQAFAHABAIQACAKAAAKIAAA7g");
	this.shape_27.setTransform(-60.9,-63.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AADBFQgGgCgFgEQgFgEgEgFQgCgHAAgJIAAgxIgWAAIAAgbIAWAAIAAggIAfAAIAAAgIAeAAIAAAbIgeAAIAAAiIABAIIACAGQABADADACQADABAGAAIAHAAQAEgBADgCIAAAbQgGADgGAAIgMABQgIgBgHgBg");
	this.shape_28.setTransform(-72.05,-61.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AATA3IAAg1IAAgIIgCgJQgCgEgEgDQgDgDgHAAQgFAAgEADQgEACgCAEQgCAEAAAEIgBAJIAAA2IgiAAIAAhqIAhAAIAAAOIAAAAIAEgGIAHgFIAIgEQAFgCAGAAQANAAAHAEQAIAEAEAHQAFAHABAJQACAJAAALIAAA6g");
	this.shape_29.setTransform(-24.45,-84.425);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AglA3IAAhqIAhAAIAAARIABAAQAEgKAHgFQAIgFALAAIAFAAIAGABIAAAeIgHgBIgHgBQgKAAgFADQgGADgDAEQgCAFgBAHIgBANIAAAtg");
	this.shape_30.setTransform(-35.375,-84.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgfAzQgIgEgEgHQgEgGgCgKQgCgJABgLIAAg6IAgAAIAAA1IABAIIACAJQACAFADACQADADAHAAQAFAAAEgCQAEgDACgEQADgDAAgFIABgJIAAg2IAgAAIAABqIgfAAIAAgOIAAAAIgFAGIgHAFIgIAEQgFACgGAAQgMAAgIgEg");
	this.shape_31.setTransform(-46.8,-84.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AADBFQgGgCgFgDQgGgFgCgFQgEgHAAgJIAAgyIgVAAIAAgaIAVAAIAAgfIAgAAIAAAfIAdAAIAAAaIgdAAIAAAjIABAIIACAHQACACADABQADACAFAAIAHgBQAEAAACgCIAAAbQgFACgGABIgLABQgJAAgHgCg");
	this.shape_32.setTransform(-57.95,-85.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgWA0QgLgEgIgHQgIgIgEgKQgGgKAAgNQAAgLAGgLQAEgLAIgHQAIgHALgEQALgEALAAQANAAAKAEQALAEAIAHQAJAHAEALQAFALgBALQABANgFAKQgEAKgJAIQgIAHgLAEQgKAEgNAAQgLAAgLgEgAgSgSQgIAHABALQgBAMAIAHQAGAIAMAAQAMAAAIgIQAGgHABgMQgBgLgGgHQgIgIgMAAQgMAAgGAIg");
	this.shape_33.setTransform(-75.85,-84.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AADBFQgGgCgGgDQgEgFgEgFQgDgHAAgJIAAgyIgUAAIAAgaIAUAAIAAgfIAhAAIAAAfIAcAAIAAAaIgcAAIAAAjIAAAIIACAHQABACAEABQADACAFAAIAHgBQAEAAACgCIAAAbQgFACgGABIgMABQgIAAgHgCg");
	this.shape_34.setTransform(-87.4,-85.75);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgSA0QgLgEgIgHQgIgIgEgKQgFgKAAgNQAAgMAFgKQAEgLAIgHQAIgHALgEQALgEAMAAQALAAAJAEQAKAEAGAHQAHAHADALQAEAKAAAMIAAALIhMAAQACAJAHAFQAGAGAJAAQAIAAAGgDQAFgEAFgGIAXARQgIAKgMAFQgMAGgNAAQgMAAgLgEgAAWgLQAAgJgGgFQgGgHgJAAQgEAAgEACQgEACgDADQgDACgCAEQgCAEAAAEIArAAIAAAAg");
	this.shape_35.setTransform(-35.875,-108.35);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAzA3IAAg+QAAgHgDgFQgDgGgJAAQgFAAgEACQgDACgDADQgDAEgBAEIgBAJIAAA4IggAAIAAg4IAAgHIgBgIQgBgDgDgDQgDgDgGAAQgGAAgEADQgFACgCAEQgCAEAAAEIgBAJIAAA2IghAAIAAhqIAgAAIAAAOIABAAIADgGIAIgFIAJgEQAFgCAFAAQAMAAAIAFQAIAEAFAKQAGgKAHgEQAJgFALAAQALAAAHAEQAIADAEAHQAFAGABAIQACAJAAAKIAAA+g");
	this.shape_36.setTransform(-51.95,-108.475);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgQBQIAAhqIAgAAIAABqgAgMguQgGgGAAgIQAAgIAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAIQAAAIgFAGQgGAFgIAAQgHAAgFgFg");
	this.shape_37.setTransform(-64.55,-110.975);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgQBOIAAh9IgsAAIAAgeIB5AAIAAAeIgsAAIAAB9g");
	this.shape_38.setTransform(-73.9,-110.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy1_mc, new cjs.Rectangle(-104.4,-127,99.30000000000001,202.4), null);


(lib.bg3_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.bg3();
	this.instance.setTransform(-150,-600,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg3_mc, new cjs.Rectangle(-150,-600,120,600), null);


(lib.bg2_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0A1482").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(59.9991,299.9992,0.4,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg2_mc, new cjs.Rectangle(0,0,120,600), null);


(lib.bg1_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E9BFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(-90,175,0.4,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg1_mc, new cjs.Rectangle(-150,-125,120,600), null);


(lib.curve2_mccopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// curve_inner
	this.instance = new lib.curve_inner_mc();
	this.instance.setTransform(0,-52.8,1,1,0,0,0,0,-52.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.curve2_mccopy, new cjs.Rectangle(-55,-90.5,110,90.5), null);


(lib.curve2_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// curve_inner_MASK (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgdA4IAAhvIA7AAIAABvg");
	var mask_graphics_7 = new cjs.Graphics().p("ADoDiIAAnDIIqAAIAAHDgAsRATIAAhwIA7AAIAABwg");
	var mask_graphics_11 = new cjs.Graphics().p("ADlHCIAAuDIIrAAIAAHDIAFAAIAAHAgAsUjMIAAhxIA8AAIAABxg");
	var mask_graphics_18 = new cjs.Graphics().p("Ak7HCIAAnCIIgAAIAAnBIIrAAIAAHDIAFAAIAAHAgAsUjMIAAhxIA8AAIAABxg");
	var mask_graphics_25 = new cjs.Graphics().p("Ak7HCIAAuDIRLAAIAAHDIAFAAIAAHAgAsUjMIAAhxIA8AAIAABxg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-99,y:-71.625}).wait(7).to({graphics:mask_graphics_7,x:-23.35,y:-67.875}).wait(4).to({graphics:mask_graphics_11,x:-23.1,y:-45.475}).wait(7).to({graphics:mask_graphics_18,x:-23.1,y:-45.475}).wait(7).to({graphics:mask_graphics_25,x:-23.1,y:-45.475}).wait(5));

	// curve_inner
	this.instance = new lib.curve_inner_mc();
	this.instance.setTransform(0,-52.8,1,1,0,0,0,0,-52.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-53.2,rotation:360,y:-53.2},29).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.2,-90.5,132,90.5);


(lib.curve_rotate_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_44 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(1));

	// Layer_2
	this.instance = new lib.curve2_mccopy();
	this.instance.setTransform(-103,85.85,1,1,0,0,0,-23.5,-45.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45));

	// copy1
	this.instance_1 = new lib.copy1_mc();
	this.instance_1.setTransform(-23.8,-44.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(39).to({alpha:0},5).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-134.5,-171.3,110,302.4);


// stage content:
(lib._120x600_car = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [290];
	// timeline functions:
	this.frame_290 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(290).call(this.frame_290).wait(1));

	// logo2
	this.instance = new lib.logo2_mc();
	this.instance.setTransform(209.5,209.5,1,1,0,0,0,80.5,33.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(215).to({_off:false},0).to({alpha:1},9).wait(67));

	// tcs
	this.instance_1 = new lib.tcs();
	this.instance_1.setTransform(64.25,235.3,1,1,0,0,0,35,31.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(281).to({_off:false},0).to({alpha:1},9).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("EgXRgutMAujAAAMAAABdbMgujAAAg");
	this.shape.setTransform(59.9948,300,0.396,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(291));

	// logo1
	this.instance_2 = new lib.logo1_mc();
	this.instance_2.setTransform(227,213.5,1,1,0,0,0,64,19.5);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},5).wait(195).to({alpha:0},5).wait(86));

	// cta
	this.instance_3 = new lib.cta_mc();
	this.instance_3.setTransform(102,361.55,1,1,0,0,0,68,9.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(215).to({_off:false},0).to({y:371.55,alpha:1},9).wait(25).to({regX:24.7,regY:-0.1,x:58.7,y:361.95},0).to({regX:24.8,scaleX:1.1733,scaleY:1.1733,x:58.85},6).to({regX:24.7,scaleX:1,scaleY:1,x:58.7},5).wait(10).to({regX:24.8,scaleX:1.1733,scaleY:1.1733,x:58.85},6).to({regX:24.7,scaleX:1,scaleY:1,x:58.7},5).wait(10));

	// loans
	this.instance_4 = new lib.loans_mc();
	this.instance_4.setTransform(107.95,327.25,1,1,0,0,0,81,18.7);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(215).to({_off:false},0).to({y:337.25,alpha:1},9).wait(67));

	// curve_rotate
	this.instance_5 = new lib.curve_rotate_mc();
	this.instance_5.setTransform(60.3,256.1,1,1,0,0,0,-79.2,48.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(160).to({_off:false},0).to({rotation:180,x:60.4,y:256.2},15).wait(116));

	// curve
	this.instance_6 = new lib.curve2_mc("synched",0,false);
	this.instance_6.setTransform(60,294.3,1,1,0,0,0,0,-45.2);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(100).to({_off:false},0).to({_off:true},61).wait(130));

	// copy1_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_4 = new cjs.Graphics().p("Aj/CJIAAkRIH/AAIAAERg");
	var mask_graphics_7 = new cjs.Graphics().p("AnAEaIAAkTIH/AAIAAETgAg+gGIAAkTIH/AAIAAETg");
	var mask_graphics_10 = new cjs.Graphics().p("AoQEaIAAkTIIBAAIAAETgAAQEMIAAkSIieAAIAAkTIIAAAIAAETICfAAIAAESg");
	var mask_graphics_13 = new cjs.Graphics().p("AiOGGIAAjZImCAAIAAkSIIBAAIAADZIAfAAIAAjnIieAAIAAkSIIAAAIAAESICfAAIAAETIifAAIAADmg");
	var mask_graphics_16 = new cjs.Graphics().p("AiOH4IAAjDIKWAAIAADDgAiOEVIAAjZImCAAIAAkSIIBAAIAADYIAfAAIAAjmIieAAIAAkTIIAAAIAAETICfAAIAAESIifAAIAADng");
	var mask_graphics_19 = new cjs.Graphics().p("AkEJ9IAAj8IMaAAIAAD8gAiTFyIAAjDIKVAAIAADDgAiTCPIAAjYImCAAIAAkTIIAAAIAADaIAgAAIAAjoIieAAIAAkSIH/AAIAAESICfAAIAAEUIifAAIAADlg");
	var mask_graphics_22 = new cjs.Graphics().p("AjALiIAAjJIhEAAIAAj8IMaAAIAAD8IhmAAIAADJgAiTEOIAAjDIKVAAIAADDgAiTArIAAjYImCAAIAAkTIIAAAIAADaIAgAAIAAjoIieAAIAAkSIH/AAIAAESICfAAIAAEUIifAAIAADlg");
	var mask_graphics_25 = new cjs.Graphics().p("AkENiIAAjZIH9AAIAADZgAjAJhIAAjIIhEAAIAAj9IMaAAIAAD9IhmAAIAADIgAiTCNIAAjCIKVAAIAADCgAiThUIAAjaImCAAIAAkTIIAAAIAADaIAgAAIAAjnIieAAIAAkTIH/AAIAAETICfAAIAAETIifAAIAADng");
	var mask_graphics_28 = new cjs.Graphics().p("AkENiIAAjZIH9AAIAADZgAENNTIAAjFIDGAAIAADFgAjAJhIAAjIIhEAAIAAj9IMaAAIAAD9IhmAAIAADIgAiTCNIAAjCIKVAAIAADCgAiThUIAAjaImCAAIAAkTIIAAAIAADaIAgAAIAAjnIieAAIAAkTIH/AAIAAETICfAAIAAETIifAAIAADng");
	var mask_graphics_31 = new cjs.Graphics().p("AmDPaIAAjPIH4AAIAADPgAkELqIAAjZIH9AAIAADZgAENLbIAAjFIDGAAIAADFgAjAHpIAAjIIhEAAIAAj9IMaAAIAAD9IhmAAIAADIgAiTAVIAAjCIKVAAIAADCgAiTjMIAAjaImCAAIAAkTIIAAAIAADaIAgAAIAAjnIieAAIAAkTIH/AAIAAETICfAAIAAETIifAAIAADng");
	var mask_graphics_34 = new cjs.Graphics().p("AmDPaIAAjPINTAAIAADKIlbAAIAAAFgAkELqIAAjZIH9AAIAADZgAENLbIAAjFIDGAAIAADFgAjAHpIAAjIIhEAAIAAj9IMaAAIAAD9IhmAAIAADIgAiTAVIAAjCIKVAAIAADCgAiTjMIAAjaImCAAIAAkTIIAAAIAADaIAgAAIAAjnIieAAIAAkTIH/AAIAAETICfAAIAAETIifAAIAADng");
	var mask_graphics_37 = new cjs.Graphics().p("AmcPaIAAjPIPLAAIAADKInTAAIAAAFgAkdLqIAAjZIH9AAIAADZgAD0LbIAAjFIDGAAIAADFgAjZHpIAAjIIhEAAIAAj9IMaAAIAAD9IhmAAIAADIgAisAVIAAjCIKVAAIAADCgAisjMIAAjaImCAAIAAkTIIAAAIAADaIAhAAIAAjnIifAAIAAkTIH/AAIAAETICfAAIAAETIifAAIAADng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_4,x:59.875,y:49}).wait(3).to({graphics:mask_graphics_7,x:40.575,y:63.425}).wait(3).to({graphics:mask_graphics_10,x:48.525,y:63.425}).wait(3).to({graphics:mask_graphics_13,x:48.525,y:74.3}).wait(3).to({graphics:mask_graphics_16,x:48.525,y:85.625}).wait(3).to({graphics:mask_graphics_19,x:49.075,y:99}).wait(3).to({graphics:mask_graphics_22,x:49.075,y:109}).wait(3).to({graphics:mask_graphics_25,x:49.075,y:121.875}).wait(3).to({graphics:mask_graphics_28,x:49.075,y:121.875}).wait(3).to({graphics:mask_graphics_31,x:49.075,y:133.875}).wait(3).to({graphics:mask_graphics_34,x:49.075,y:133.875}).wait(3).to({graphics:mask_graphics_37,x:51.575,y:133.875}).wait(254));

	// copy1
	this.instance_7 = new lib.copy1_mc();
	this.instance_7.setTransform(115.2,163.7);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({_off:false},0).to({_off:true},156).wait(131));

	// bg3
	this.instance_8 = new lib.bg3_mc();
	this.instance_8.setTransform(150,725,1,1,0,0,0,0,-125);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(190).to({_off:false},0).to({y:475},25).wait(76));

	// bg2
	this.instance_9 = new lib.bg2_mc();
	this.instance_9.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(95).to({alpha:0},5).wait(191));

	// bg1
	this.instance_10 = new lib.bg1_mc();
	this.instance_10.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(291));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(20.9,300,263.6,550);
// library properties:
lib.properties = {
	id: '0D31762BEC544CDCAFB5F74A7943328F',
	width: 120,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/120x600_car_atlas_P_1.png?1614697830457", id:"120x600_car_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0D31762BEC544CDCAFB5F74A7943328F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;