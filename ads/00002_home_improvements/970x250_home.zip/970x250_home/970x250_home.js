(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"970x250_home_atlas_P_1", frames: [[0,0,1940,500],[382,502,350,107],[0,502,380,159]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg3 = function() {
	this.initialize(ss["970x250_home_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["970x250_home_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.logo2 = function() {
	this.initialize(ss["970x250_home_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#081A7D").s().p("AgyBLIAAiRIAtAAIAAAXIAAAAQAGgNAKgHQAKgHAPAAIAIABIAHABIAAApIgJgCIgKgBQgNAAgHAEQgIADgEAHQgDAGgBAJIgBATIAAA9g");
	this.shape.setTransform(460.175,24.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#081A7D").s().p("AgYBHQgPgFgLgLQgLgJgHgPQgGgNAAgSQAAgQAGgPQAHgNALgKQALgLAPgFQAOgGAQAAQAQAAAMAGQANAFAJALQAJAKAFANQAFAPAAAQIAAAPIhoAAQADAMAJAIQAJAIAMAAQALgBAIgFQAHgFAGgHIAgAXQgLAOgRAHQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAGQgEAEgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape_1.setTransform(445.225,24.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#081A7D").s().p("AAZByIAAhIIAAgNQgBgHgCgFQgCgGgFgDQgFgFgIAAQgIAAgFAEQgGADgDAFQgDAGAAAGIgBAOIAABJIgtAAIAAjjIAtAAIAABmIAAAAIAFgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAEAGAKQAGAJACAMQACAMAAAPIAABRg");
	this.shape_2.setTransform(428.375,20.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#081A7D").s().p("AAEBeQgIgCgIgGQgHgFgEgIQgEgJAAgMIAAhEIgdAAIAAgkIAdAAIAAgrIAsAAIAAArIAnAAIAAAkIgnAAIAAAwIABALIACAIQADAEAEACQAEACAIAAIAJgBQAGgBACgDIAAAmQgHADgIAAIgQABQgLAAgKgCg");
	this.shape_3.setTransform(413.75,22.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#081A7D").s().p("AgYBHQgPgFgLgLQgLgJgHgPQgGgNAAgSQAAgQAGgPQAHgNALgKQALgLAPgFQAOgGAQAAQAQAAAMAGQANAFAJALQAJAKAFANQAFAPAAAQIAAAPIhoAAQADAMAJAIQAJAIAMAAQALgBAIgFQAHgFAGgHIAgAXQgLAOgRAHQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAGQgEAEgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape_4.setTransform(399.675,24.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#081A7D").s().p("AgrBqQgTgEgPgNIAZglQAKAJAMAFQALAFAOAAQAUAAAJgKQAKgKAAgQIAAgOIAAAAQgIALgMAEQgLAFgKAAQgQAAgNgGQgNgFgKgLQgJgKgFgMQgFgOAAgRQAAgOAEgOQAFgOAJgKQAIgLAMgGQANgHAPAAQAKAAAHACIAOAGIALAHIAHAIIABAAIAAgTIApAAIAACEQAAAqgVAVQgVAWgpAAQgUAAgTgFgAgMhDQgGADgFAFQgFAFgDAGQgCAHAAAHQAAAHACAHQADAGAFAFQAFAFAGADQAHACAHAAQAHAAAHgCQAGgDAFgFQAFgFADgGQADgHAAgHQAAgHgDgHQgDgGgFgFQgFgFgGgDQgHgDgHAAQgHAAgHADg");
	this.shape_5.setTransform(381.475,28.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#081A7D").s().p("AgfBHQgOgFgMgLQgKgJgHgPQgGgNAAgSQAAgQAGgPQAHgNAKgKQAMgLAOgFQAPgGAQAAQARAAAOAGQAPAFALALQAMAKAGANQAGAPAAAQQAAASgGANQgGAPgMAJQgLALgPAFQgOAGgRgBQgQABgPgGgAgZgaQgKALAAAPQAAARAKAKQAJAKAQAAQARAAAKgKQAJgKAAgRQAAgPgJgLQgKgKgRAAQgQAAgJAKg");
	this.shape_6.setTransform(363.7,24.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#081A7D").s().p("AAEBeQgIgCgHgGQgIgFgEgIQgEgJAAgMIAAhEIgdAAIAAgkIAdAAIAAgrIAsAAIAAArIAoAAIAAAkIgoAAIAAAwIAAALIAEAIQABAEAFACQAEACAIAAIAJgBQAGgBADgDIAAAmQgIADgIAAIgQABQgLAAgKgCg");
	this.shape_7.setTransform(348.55,22.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#081A7D").s().p("AgkBuQgNgGgKgKQgJgKgFgOQgFgNAAgRQAAgPAEgOQAFgNAJgLQAIgLAMgGQANgHAPAAQANAAANAFQAMAEAIALIAAAAIAAhhIAtAAIAADiIgpAAIAAgTIgBAAIgHAHIgKAIIgNAFQgHACgHAAQgQAAgNgFgAgYAMQgJAKAAARQAAAQAJALQAKAKAQAAQARAAAJgKQAKgLAAgQQAAgRgKgKQgJgKgRAAQgQAAgKAKg");
	this.shape_8.setTransform(324.625,20.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#081A7D").s().p("AAZBLIAAhIIAAgMQgBgHgCgFQgCgGgFgDQgFgEgIAAQgIAAgFADQgGADgDAFQgDAGAAAGIgBANIAABJIgtAAIAAiRIArAAIAAAUIABAAIAGgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAFAGAJQAGAJACANQACANAAAOIAABQg");
	this.shape_9.setTransform(307.425,24.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#081A7D").s().p("AgrBGQgLgGgGgJQgFgJgCgNQgCgMAAgPIAAhQIAtAAIAABIIAAAMQABAHACAFQACAGAFAEQAEADAJAAQAIAAAFgDQAGgDACgFQADgFABgHIABgNIAAhJIAtAAIAACRIgrAAIAAgUIgBAAIgGAJIgJAHIgLAGQgHACgIAAQgSAAgKgFg");
	this.shape_10.setTransform(290.575,24.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#081A7D").s().p("AgeBHQgPgFgMgLQgKgJgHgPQgGgNAAgSQAAgQAGgPQAHgNAKgKQAMgLAPgFQAOgGAQAAQARAAAOAGQAPAFAMALQALAKAGANQAGAPAAAQQAAASgGANQgGAPgLAJQgMALgPAFQgOAGgRgBQgQABgOgGgAgZgaQgKALAAAPQAAARAKAKQAJAKAQAAQARAAAJgKQAKgKAAgRQAAgPgKgLQgJgKgRAAQgQAAgJAKg");
	this.shape_11.setTransform(273.15,24.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#081A7D").s().p("AgyBLIAAiRIAtAAIAAAXIAAAAQAGgNAKgHQAKgHAPAAIAIABIAHABIAAApIgJgCIgKgBQgNAAgHAEQgIADgEAHQgDAGgBAJIgBATIAAA9g");
	this.shape_12.setTransform(259.425,24.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#081A7D").s().p("AglBJQgJgCgHgGQgIgGgEgIQgEgJAAgLQAAgMAFgJQAEgJAIgEQAIgGAKgDQAKgDALgCIAVgBIAVAAQAAgMgJgIQgJgHgLAAQgKAAgJAFQgKAEgHAJIgYgZQANgLARgHQAQgFARgBQAUABANAEQANAFAHAKQAIAKADANQADAOAAATIAABJIgpAAIAAgTIgBAAQgHANgNAFQgLAEgOAAQgKAAgKgDgAAFAJIgOADQgHADgFADQgFAEAAAIQAAAIAHAEQAHAEAHAAQAGAAAGgCQAGgCAFgDQAFgDADgGQADgEAAgIIAAgJIgMAAg");
	this.shape_13.setTransform(244.825,24.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#081A7D").s().p("AgjBJQgPgFgLgMIAbgdQAGAHAIAEQAIAFAKAAQAHAAAGgDQAGgCAAgGQAAgFgFgDQgGgEgHgCIgSgDQgKgDgJgEQgIgFgGgHQgFgJAAgNQAAgNAFgKQAFgIAJgGQAIgHALgCQALgDALgBQAOAAAPAFQAPAEAKALIgcAbQgKgMgQAAQgFAAgFADQgFACAAAHQAAAFAFADIANAEIATAEQAJADAJAEQAIAGAGAHQAFAIAAANQAAAPgGAJQgGAJgJAFQgKAGgMACQgMACgLAAQgPAAgQgDg");
	this.shape_14.setTransform(221.875,24.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#081A7D").s().p("AgrBqQgTgEgPgNIAZglQAKAJAMAFQALAFAOAAQAUAAAJgKQAKgKAAgQIAAgOIAAAAQgIALgMAEQgLAFgKAAQgQAAgNgGQgNgFgKgLQgJgKgFgMQgFgOAAgRQAAgOAEgOQAFgOAJgKQAIgLAMgGQANgHAPAAQAKAAAHACIAOAGIALAHIAHAIIABAAIAAgTIApAAIAACEQAAAqgVAVQgVAWgpAAQgUAAgTgFgAgMhDQgGADgFAFQgFAFgDAGQgCAHAAAHQAAAHACAHQADAGAFAFQAFAFAGADQAHACAHAAQAHAAAHgCQAGgDAFgFQAFgFADgGQADgHAAgHQAAgHgDgHQgDgGgFgFQgFgFgGgDQgHgDgHAAQgHAAgHADg");
	this.shape_15.setTransform(205.375,28.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#081A7D").s().p("AAZBLIAAhIIAAgMQgBgHgCgFQgCgGgFgDQgFgEgIAAQgIAAgFADQgGADgDAFQgDAGAAAGIgBANIAABJIgtAAIAAiRIArAAIAAAUIABAAIAGgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAFAGAJQAGAJACANQACANAAAOIAABQg");
	this.shape_16.setTransform(188.175,24.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#081A7D").s().p("AgVBtIAAiRIAsAAIAACRgAgSg/QgHgIAAgKQAAgLAHgIQAJgIAJAAQALAAAHAIQAIAIAAALQAAAKgIAIQgHAHgLABQgJgBgJgHg");
	this.shape_17.setTransform(176,21.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#081A7D").s().p("AAZByIAAhIIAAgNQgBgHgCgFQgCgGgFgDQgFgFgIAAQgIAAgFAEQgGADgDAFQgDAGAAAGIgBAOIAABJIgtAAIAAjjIAtAAIAABmIAAAAIAFgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAEAGAKQAGAJACAMQACAMAAAPIAABRg");
	this.shape_18.setTransform(163.875,20.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#081A7D").s().p("AAEBeQgIgCgIgGQgHgFgEgIQgEgJAAgMIAAhEIgcAAIAAgkIAcAAIAAgrIAsAAIAAArIAnAAIAAAkIgnAAIAAAwIABALIACAIQACAEAFACQAEACAHAAIAKgBQAFgBADgDIAAAmQgHADgIAAIgQABQgLAAgKgCg");
	this.shape_19.setTransform(149.25,22.725);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#081A7D").s().p("AAZBLIAAhIIAAgMQgBgHgCgFQgCgGgFgDQgFgEgIAAQgIAAgFADQgGADgDAFQgDAGAAAGIgBANIAABJIgtAAIAAiRIArAAIAAAUIABAAIAGgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAFAGAJQAGAJACANQACANAAAOIAABQg");
	this.shape_20.setTransform(126.675,24.525);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#081A7D").s().p("AgyBLIAAiRIAtAAIAAAXIAAAAQAGgNAKgHQAKgHAPAAIAIABIAHABIAAApIgJgCIgKgBQgNAAgHAEQgIADgEAHQgDAGgBAJIgBATIAAA9g");
	this.shape_21.setTransform(112.375,24.525);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#081A7D").s().p("AgrBGQgLgGgGgJQgFgJgCgNQgCgMAAgPIAAhQIAtAAIAABIIAAAMQABAHACAFQACAGAFAEQAEADAJAAQAIAAAFgDQAGgDACgFQADgFABgHIABgNIAAhJIAtAAIAACRIgrAAIAAgUIgBAAIgGAJIgJAHIgLAGQgHACgIAAQgSAAgKgFg");
	this.shape_22.setTransform(97.425,24.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#081A7D").s().p("AAEBeQgIgCgIgGQgHgFgEgIQgEgJAAgMIAAhEIgdAAIAAgkIAdAAIAAgrIAsAAIAAArIAoAAIAAAkIgoAAIAAAwIAAALIAEAIQACAEAEACQAEACAIAAIAJgBQAGgBADgDIAAAmQgIADgIAAIgQABQgLAAgKgCg");
	this.shape_23.setTransform(82.8,22.725);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#081A7D").s().p("AgjBJQgPgFgLgMIAbgdQAGAHAIAEQAIAFAKAAQAHAAAGgDQAGgCAAgGQAAgFgFgDQgGgEgHgCIgSgDQgKgDgJgEQgIgFgGgHQgFgJAAgNQAAgNAFgKQAFgIAJgGQAIgHALgCQALgDALgBQAOAAAPAFQAPAEAKALIgcAbQgKgMgQAAQgFAAgFADQgFACAAAHQAAAFAFADIANAEIATAEQAJADAJAEQAIAGAGAHQAFAIAAANQAAAPgGAJQgGAJgJAFQgKAGgMACQgMACgLAAQgPAAgQgDg");
	this.shape_24.setTransform(61.875,24.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#081A7D").s().p("AgSArIAAhVIAlAAIAABVg");
	this.shape_25.setTransform(50.9,15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#081A7D").s().p("AAEBeQgJgCgGgGQgIgFgEgIQgEgJAAgMIAAhEIgcAAIAAgkIAcAAIAAgrIAsAAIAAArIAnAAIAAAkIgnAAIAAAwIABALIACAIQACAEAFACQAEACAHAAIAKgBQAFgBADgDIAAAmQgHADgIAAIgQABQgLAAgKgCg");
	this.shape_26.setTransform(40.45,22.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#081A7D").s().p("AgYBHQgPgFgLgLQgLgJgHgPQgGgNAAgSQAAgQAGgPQAHgNALgKQALgLAPgFQAOgGAQAAQAQAAAMAGQANAFAJALQAJAKAFANQAFAPAAAQIAAAPIhoAAQADAMAJAIQAJAIAMAAQALgBAIgFQAHgFAGgHIAgAXQgLAOgRAHQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAGQgEAEgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape_27.setTransform(26.375,24.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#081A7D").s().p("AhCBqIAAjTIAvAAIAACoIBWAAIAAArg");
	this.shape_28.setTransform(11.025,21.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_anim, new cjs.Rectangle(0,0,467.5,45), null);


(lib.tcs_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0A1482").s().p("AgDAEQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBABgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape.setTransform(172.15,-6.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0A1482").s().p("AgJAkQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgFABgFQACgDADgDQADgDAFgCQAEgCAFAAQAEAAAFACQAEACACADIABAAIAAghIAIAAIAABJIgIAAIAAgHIgBAAQgCAEgFACQgEACgEAAQgFgBgEgBgAgFAAIgFACIgDAEIgBAHIABAHIADAFIAFADQADABACAAQAEAAADgBIAFgDIADgFIABgHIgBgHIgDgEIgFgCQgDgCgEAAQgCAAgDACg");
	this.shape_1.setTransform(167.875,-9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_2.setTransform(162.475,-7.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQgBABAAABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_3.setTransform(157.325,-7.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_4.setTransform(153.825,-9.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_5.setTransform(150.125,-7.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0A1482").s().p("AgMAYIAAguIAJAAIAAAHIACgDIACgDIAFgBIADgBIAFABIgBAJIgCAAIgCAAQgHAAgCADQgEAEABAGIAAAYg");
	this.shape_6.setTransform(145.95,-7.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0A1482").s().p("AgEAjIAAhFIAJAAIAABFg");
	this.shape_7.setTransform(142.775,-9.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0A1482").s().p("AgFAmIAAgmIgKAAIAAgIIAKAAIAAgKQAAgJADgFQADgFAJAAIADABIADAAIgBAIIgCgBIgDAAIgEABIgCACIgBADIAAAFIAAAKIAKAAIAAAIIgKAAIAAAmg");
	this.shape_8.setTransform(137.375,-9.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0A1482").s().p("AgJAXQgEgCgEgEQgDgDgCgEQgCgFAAgFQAAgEACgEQACgFADgDQAEgEAEgBQAFgCAEAAQAFAAAFACQAEABADAEQAEADACAFQACAEAAAEQAAAFgCAFQgCAEgEADQgDAEgEACQgFABgFAAQgEAAgFgBgAgGgOIgEADIgDAFIgBAGIABAHIADAFIAEADQADABADAAQADAAADgBIAFgDIADgFIABgHIgBgGIgDgFIgFgDQgDgBgDAAQgDAAgDABg");
	this.shape_9.setTransform(133.025,-7.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0A1482").s().p("AAJAlIgVgYIAAAYIgJAAIAAhJIAJAAIAAAuIATgTIANAAIgVAUIAXAag");
	this.shape_10.setTransform(125.45,-9.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_11.setTransform(120.125,-7.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQgBABAAABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_12.setTransform(114.975,-7.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0A1482").s().p("AgXAjIAAhFIAXAAIAIABIAHAEQADACACADQABADAAAFQAAAGgDADQgEAEgFACQADAAADABIAFAEIADAFIABAGQAAAFgCAEQgCADgDADQgDACgEABQgFACgFAAgAgNAbIANAAIAEgBIAEgCIAFgDQABgDAAgDQAAgGgEgDQgEgEgGAAIgNAAgAgNgFIAMAAIAEAAIAEgCIADgDIABgFQAAgEgDgDQgCgDgGAAIgNAAg");
	this.shape_13.setTransform(109.8,-9.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_14.setTransform(102.925,-9.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQAAABgBABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_15.setTransform(99.325,-7.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#0A1482").s().p("AgNAYIAAguIAJAAIAAAHIADgDIADgDIADgBIAFgBIADABIAAAJIgCAAIgCAAQgGAAgDADQgDAEgBAGIAAAYg");
	this.shape_16.setTransform(95.4,-7.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCgBgDIAAgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIABACIAFABIADAAIADgBIAAAIIgEABg");
	this.shape_17.setTransform(91.55,-8.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_18.setTransform(87.425,-7.975);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_19.setTransform(82.175,-7.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0A1482").s().p("AgJAhQgHgDgEgFQgFgFgDgHQgCgGAAgHQAAgHADgHQADgGAEgFQAFgFAGgDQAHgDAIABQAGgBAHADQAGACAFAGIgIAGQgDgDgEgDQgFgCgFAAQgFAAgEACQgGACgDAFQgDADgCAGQgCAFAAAEQAAAGACAFQACAFADADIAIAHQAFABAFAAQAGAAAEgCQAFgCADgFIAIAGIgDADIgFAEIgIAEQgEABgGAAQgHAAgHgDg");
	this.shape_20.setTransform(76.3,-9.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_21.setTransform(67.675,-7.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#0A1482").s().p("AAMAlIAAgcIgBgFIgCgEIgEgBIgEAAIgEAAIgEACIgDAFIgBAHIAAAYIgJAAIAAhJIAJAAIAAAjQACgEAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAEIAAAeg");
	this.shape_22.setTransform(62.425,-9.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIACACIADABIAEAAIADgBIAAAIIgEABg");
	this.shape_23.setTransform(57.85,-8.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#0A1482").s().p("AgRAjIgFgBIACgJIAFACIADgBIADgCIACgCIABgDIADgHIgUguIALAAIANAkIAAAAIANgkIAJAAIgVA4IgCAFIgDAEIgEADIgGABg");
	this.shape_24.setTransform(51.4,-6.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#0A1482").s().p("AgIAkQgEgCgCgEIAAAHIgJAAIAAhJIAJAAIAAAhQACgDAEgCQAFgCAEAAQAFAAAFACQAEACADADQADADACADQACAFgBAFQABAFgCAFQgCAEgDADQgDAEgEACQgFABgFABQgEAAgFgCgAgFAAIgGACIgCAEIgBAHIABAHIACAFIAGADQACABADAAQADAAADgBIAFgDIADgFIABgHIgBgHIgDgEIgFgCQgDgCgDAAQgDAAgCACg");
	this.shape_25.setTransform(46.25,-9.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#0A1482").s().p("AgJAkQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgFABgFQACgDADgDQADgDAFgCQAEgCAFAAQAEAAAFACQAEACACADIABAAIAAghIAIAAIAABJIgIAAIAAgHIgBAAQgCAEgFACQgEACgEAAQgFgBgEgBgAgFAAIgFACIgDAEIgBAHIABAHIADAFIAFADQADABACAAQAEAAADgBIAFgDIADgFIABgHIgBgHIgDgEIgFgCQgDgCgEAAQgCAAgDACg");
	this.shape_26.setTransform(37.675,-9.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_27.setTransform(32.275,-7.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIACACIADABIAEAAIADgBIAAAIIgEABg");
	this.shape_28.setTransform(27.7,-8.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQgBABAAABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_29.setTransform(23.675,-7.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_30.setTransform(20.175,-9.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#0A1482").s().p("AgJAXIgGgDIgDgGQgCgDAAgFIAAgdIAJAAIAAAbIABAFQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAIAEACIAEABIAEgBIAEgDIADgFIABgHIAAgXIAJAAIAAAuIgJAAIAAgHQgCADgEADQgEACgFAAIgGgBg");
	this.shape_31.setTransform(16.475,-7.875);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#0A1482").s().p("AgMAiQgGgCgFgFIAGgHQAEAEAEACQAEABAFAAQAEAAADgBIAFgEQACgCABgDIABgGIAAgHIgBAAQgCAFgFABQgEACgEAAQgFAAgEgBQgFgCgDgDIgFgHQgBgEAAgFQAAgGABgEIAFgHQADgEAFgCQAEgCAFAAQAEAAAEACQAFACACAEIABAAIAAgHIAIAAIAAAtQAAAGgBAEIgFAIQgEADgFACQgEABgFABQgHAAgFgCgAgFgZIgFADIgDAFIgBAHQAAAHAEADQAEAFAGgBQAHABAFgFQAEgDAAgHIgBgHIgDgFIgFgDQgDgCgEABQgCgBgDACg");
	this.shape_32.setTransform(10.825,-6.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_33.setTransform(5.425,-7.925);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#0A1482").s().p("AgMAYIAAguIAJAAIAAAHIACgDIADgDIADgBIAEgBIAFABIgBAJIgCAAIgCAAQgHAAgCADQgDAEAAAGIAAAYg");
	this.shape_34.setTransform(1.25,-7.975);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#0A1482").s().p("AgKAXQgEgCgEgFIAHgFIAFAEQADABADAAIADAAIADgBIACgCIABgDIgBgDIgDgCIgDgBIgDgBIgFgBIgFgCIgDgEQgBgCAAgDQAAgEABgCIAEgFIAGgDIAGAAIAJABQAEACACAEIgGAFIgFgDQgCgBgDAAQgCAAgDABQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIACACIAEACIADAAIAGACIADACIADADIACAGQAAAEgCADIgEAEIgHADIgGAAQgFAAgFgBg");
	this.shape_35.setTransform(-5.4,-7.925);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABABABAAQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_36.setTransform(-8.525,-9.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_37.setTransform(-14.775,-7.975);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#0A1482").s().p("AgJAXQgEgCgEgEQgDgDgCgEQgCgFAAgFQAAgEACgEQACgFADgDQAEgEAEgBQAFgCAEAAQAFAAAFACQAEABADAEQAEADACAFQACAEAAAEQAAAFgCAFQgCAEgEADQgDAEgEACQgFABgFAAQgEAAgFgBgAgGgOIgEADIgDAFIgBAGIABAHIADAFIAEADQADABADAAQADAAADgBIAFgDIADgFIABgHIgBgGIgDgFIgFgDQgDgBgDAAQgDAAgDABg");
	this.shape_38.setTransform(-20.225,-7.925);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABABABAAQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_39.setTransform(-24.175,-9.075);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#0A1482").s().p("AAMAYIAAgbIgBgFIgCgEIgEgCIgEgBIgEABIgEADIgDAFIgBAGIAAAYIgJAAIAAguIAJAAIAAAHQACgDAEgDQAEgCAFAAIAGABIAGADIADAGQACADAAAFIAAAdg");
	this.shape_40.setTransform(-27.875,-7.975);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#0A1482").s().p("AgKAiQgEgCgEgEQgDgEgDgFQgCgFAAgGIAAgrIAJAAIAAAqIACAHIADAGIAFAFQADACAEAAQAFAAADgCIAGgFIACgGIABgHIAAgqIAKAAIAAArQAAAGgCAFQgDAFgDAEQgDAEgFACQgGACgFAAQgFAAgFgCg");
	this.shape_41.setTransform(-33.85,-8.975);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgBgCAAgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIANAAIAAAHIgNAAIAAAUIAAAEIABAEIACACIADABIAEAAIADgBIAAAIIgEABg");
	this.shape_42.setTransform(-41.7,-8.525);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABABABAAQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_43.setTransform(-44.325,-9.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#0A1482").s().p("AgJAkQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgFABgFQACgDADgDQADgDAFgCQAEgCAFAAQAEAAAFACQAEACACADIABAAIAAghIAIAAIAABJIgIAAIAAgHIgBAAQgCAEgFACQgEACgEAAQgFgBgEgBgAgFAAIgFACIgDAEIgBAHIABAHIADAFIAFADQADABACAAQAEAAADgBIAFgDIADgFIABgHIgBgHIgDgEIgFgCQgDgCgEAAQgCAAgDACg");
	this.shape_44.setTransform(-48.425,-9.25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_45.setTransform(-53.825,-7.925);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#0A1482").s().p("AgMAYIAAguIAJAAIAAAHIACgDIACgDIAFgBIADgBIAFABIgBAJIgCAAIgCAAQgGAAgDADQgDAEAAAGIAAAYg");
	this.shape_46.setTransform(-58,-7.975);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#0A1482").s().p("AgJAhQgGgDgGgFQgEgFgCgHQgDgGAAgHQAAgHADgHQACgGAFgFQAFgFAHgDQAGgDAHABQAHgBAHADQAHACADAGIgIAGQgCgDgFgDQgEgCgFAAQgFAAgFACQgEACgEAFQgDADgCAGQgCAFAAAEQAAAGACAFQACAFADADIAIAHQAFABAFAAQAGAAAFgCQAEgCADgFIAIAGIgDADIgFAEIgHAEQgFABgGAAQgHAAgHgDg");
	this.shape_47.setTransform(-63.15,-9.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#0A1482").s().p("AAIAeIgIgBQgCgBgBgDQgCgCABgDIgBgFIAAgYIgKAAIAAgHIAKAAIAAgNIAIAAIAAANIAMAAIAAAHIgMAAIAAAUIAAAEIABAEIABACIAFABIADAAIADgBIAAAIIgEABg");
	this.shape_48.setTransform(-71.1,-8.525);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#0A1482").s().p("AgKAXQgEgCgEgFIAHgFIAFAEQADABADAAIADAAIADgBIACgCIABgDIgBgDIgDgCIgDgBIgDgBIgFgBIgFgCIgDgEQgBgCAAgDQAAgEABgCIAEgFIAGgDIAGAAIAJABQAEACACAEIgGAFIgFgDQgCgBgDAAQgCAAgCABQgBABgBAAQAAABAAAAQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIACACIAEACIADAAIAGACIADACIADADIABAGQAAAEgBADIgEAEIgHADIgGAAQgFAAgFgBg");
	this.shape_49.setTransform(-74.8,-7.925);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#0A1482").s().p("AgNAYIAAguIAJAAIAAAHIADgDIACgDIAFgBIADgBIAEABIAAAJIgCAAIgCAAQgGAAgDADQgEAEAAAGIAAAYg");
	this.shape_50.setTransform(-78.35,-7.975);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#0A1482").s().p("AgDAjIAAguIAHAAIAAAugAgEgXQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgCACAAQABAAAAAAQABABABAAQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQgCAAgCgCg");
	this.shape_51.setTransform(-81.375,-9.075);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#0A1482").s().p("AgVAjIAAhFIArAAIAAAJIghAAIAAAWIAeAAIAAAIIgeAAIAAAeg");
	this.shape_52.setTransform(-84.925,-9.075);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#0A1482").s().p("AgMAYIAAguIAJAAIAAAHIACgDIACgDIAFgBIADgBIAFABIgBAJIgCAAIgCAAQgHAAgCADQgEAEABAGIAAAYg");
	this.shape_53.setTransform(-92,-7.975);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_54.setTransform(-96.525,-7.925);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#0A1482").s().p("AgHAkQgFgCgDgEIAAAHIgJAAIAAhJIAJAAIAAAhQADgDAFgCQAEgCAEAAQAFAAAFACQAEACADADQADADACADQABAFAAAFQAAAFgBAFQgCAEgDADQgDAEgEACQgFABgFABQgEAAgEgCgAgGAAIgFACIgDAEIgBAHIABAHIADAFIAFADQADABADAAQADAAADgBIAFgDIADgFIABgHIgBgHIgDgEIgFgCQgDgCgDAAQgDAAgDACg");
	this.shape_55.setTransform(-101.95,-9.25);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#0A1482").s().p("AAaAYIAAgZIAAgFQAAgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBgBIgDgDIgFgBQgGAAgDAEQgDAEAAAGIAAAZIgHAAIAAgYIgBgGIgBgEIgDgEIgFgBIgFABIgEADIgCAFIgBAGIAAAYIgJAAIAAguIAIAAIAAAIIACgDIADgDIAFgCIAFgBQAFAAAEACQADACACAFQACgFAEgCQAEgCAEAAQAGAAADACQAEACACADQACACAAAEIABAIIAAAag");
	this.shape_56.setTransform(-109.025,-7.975);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#0A1482").s().p("AgIAXQgFgCgDgEQgDgDgCgEQgBgFAAgFQAAgEABgFQACgEADgDQAEgEAEgBQAEgCAFAAQAGAAAEACQAEACADADIAEAIIABAIIAAADIgkAAIABAGIAEAEIAFADIAFABQAEAAADgCIAFgFIAHAFQgHAJgNAAQgFAAgEgBgAAOgDIgBgFQAAgBgBAAQAAgBAAgBQAAAAgBAAQAAgBgBAAIgEgDIgFgBIgFABIgFADIgDAEIgBAFIAbAAIAAAAg");
	this.shape_57.setTransform(-115.725,-7.925);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#0A1482").s().p("AAbAjIAAg4IgYA4IgFAAIgXg4IgBAAIAAA4IgJAAIAAhFIAOAAIAVA0IAWg0IAOAAIAABFg");
	this.shape_58.setTransform(-122.725,-9.075);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#0A1482").s().p("AgDAEQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBABAAQAAgBABgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_59.setTransform(-130.9,-6.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#0A1482").s().p("AgSAjIgEgBIACgJIAFACIADgBIADgCIACgCIABgDIADgHIgTguIAKAAIANAkIAAAAIANgkIAJAAIgVA4IgCAFIgDAEIgEADIgGABg");
	this.shape_60.setTransform(-134.55,-6.75);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#0A1482").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_61.setTransform(-138.025,-9.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#0A1482").s().p("AgYAlIAAhJIAJAAIAAAHQADgEAFgCQAEgCAEAAQAFAAAEACQAFACADAEIAFAHQACAEAAAGQAAAFgCAFQgCADgDADQgDADgFACQgEACgFAAQgEAAgEgCQgFgCgDgDIAAAhgAgGgbIgEADIgEAFIgBAHIABAGIAEAFIAEACQADACADAAQAEAAACgCIAFgCIADgFIABgGIgBgHIgDgFIgFgDQgCgCgEABQgDgBgDACg");
	this.shape_62.setTransform(-141.9,-6.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#0A1482").s().p("AgXAlIAAhJIAJAAIAAAHQACgEAEgCQAFgCAEAAQAFAAAFACQAEACADAEIAFAHQACAEgBAGQABAFgCAFQgCADgDADQgDADgEACQgFACgFAAQgEAAgFgCQgEgCgCgDIAAAhgAgFgbIgGADIgCAFIgBAHIABAGIACAFIAGACQACACADAAQADAAADgCIAFgCIADgFIABgGIgBgHIgDgFIgFgDQgDgCgDABQgDgBgCACg");
	this.shape_63.setTransform(-147.7,-6.6);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#0A1482").s().p("AgJAYIgGgDIgDgEIgBgGQAAgFACgDQACgDADgBIAIgDIAJgBIAHAAIAAgCIgBgDIgCgDIgDgCIgFgBIgEAAIgDABIgDACIgDACIgFgGQAEgDAFgCIAJgBIAIABIAGADQADACABADIABAGIAAAXIAAAEIAAAEIgIAAIAAgHQgDAFgEACQgEABgEAAIgGAAgAABABIgFACIgFACQAAABgBAAQAAABAAAAQgBABAAABQAAAAAAABQAAAEADACQADABAEAAIAGgBIAEgDIACgEIABgFIAAgDIgFAAg");
	this.shape_64.setTransform(-153.225,-7.925);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#0A1482").s().p("AgJAXQgFgCgDgFIAHgFIAEAEQADABADAAIADAAIADgBIACgCIABgDIgBgDIgDgCIgEgBIgCgBIgGgBIgEgCIgDgEQgBgCgBgDQABgEABgCIAEgFIAGgDIAFAAIAJABQAEACADAEIgHAFIgDgDQgDgBgDAAQgDAAgCABQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAAAAAIAEACIACACIAEAAIAFACIAEACIAEADIABAGQgBAEgBADIgFAEIgFADIgHAAQgFAAgEgBg");
	this.shape_65.setTransform(-160.35,-7.925);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#0A1482").s().p("AgJAhQgHgDgFgFQgEgFgDgHQgCgGAAgHQAAgHADgHQACgGAFgFQAFgFAGgDQAHgDAHABQAHgBAHADQAGACAFAGIgIAGQgDgDgFgDQgEgCgFAAQgFAAgEACQgFACgEAFQgDADgCAGQgCAFAAAEQAAAGACAFQABAFAEADIAIAHQAFABAFAAQAGAAAEgCQAFgCADgFIAIAGIgCADIgGAEIgIAEQgEABgGAAQgIAAgGgDg");
	this.shape_66.setTransform(-165.6,-9.05);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#0A1482").s().p("AgTAiQgEgBgDgDIgEgHQgCgDAAgEQAAgEACgDQABgDACgCIAFgEIAGgDIgGgHQgCgEAAgFQAAgEACgDQABgDADgCIAFgDIAIgBIAFABIAGADIAEAFIABAGIgBAGIgDAFIgFAEIgEADIANAOIAJgOIAKAAIgNAUIAQAQIgNAAIgJgJQgEAFgFADQgEADgHAAQgGAAgEgCgAgOAEIgEADIgDAEIgBAFIABAEIADAEIAFADIAEABIAFgBIAEgCIADgDIADgDIgQgRgAgMgZQgDACAAAEIABADIACADIACADIACADIAEgDIADgCIACgDIABgFQAAgDgCgCQgCgCgDAAQgEAAgDACg");
	this.shape_67.setTransform(-172.325,-9.025);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#0A1482").s().p("AgEAjIAAg8IgWAAIAAgJIA1AAIAAAJIgWAAIAAA8g");
	this.shape_68.setTransform(-178.7,-9.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tcs_mc, new cjs.Rectangle(-183.5,-17.4,367,17.4), null);


(lib.logo2_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo2();
	this.instance.setTransform(-95,-79.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo2_mc, new cjs.Rectangle(-95,-79.5,190,79.5), null);


(lib.logo1_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-87.5,-53.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo1_mc, new cjs.Rectangle(-87.5,-53.5,175,53.5), null);


(lib.loans_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text(" ", "14px 'Avenir Light'", "#FFFFFF");
	this.text.lineHeight = 22;
	this.text.parent = this;
	this.text.setTransform(149,-10.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZA5QgNgGgHgMIAOgJQAFAJAKAFQAJAFAKAAIAKgBQAFgCAEgDIAGgGQACgFABgFQgBgIgFgEQgGgEgHgDIgQgEIgSgEQgHgDgFgHQgGgGAAgLQAAgJAEgHQADgGAGgFQAGgEAIgCQAGgCAIAAQAOAAALAFQALAGAFAMIgNAIQgFgIgHgFQgGgEgKAAIgIABIgIAEQgEACgDAEQgCAEAAAEQAAAIAFAEQAFAEAJACIAQAEQAIACAJADQAIADAEAGQAGAHAAAMQAAAJgEAHQgDAHgGAFQgGAFgIACQgIACgIAAQgPAAgNgGg");
	this.shape.setTransform(319.95,37.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVA7QgMgFgIgIQgIgJgEgLQgEgMAAgOQAAgNAEgLQAFgLAIgJQAIgIALgFQALgFAMAAQAOAAAKAFQALAFAHAHQAHAIAEALQADAKAAAKIAAAKIhkAAIACANQACAHAFAIQAGAHAIAFQAJAFANAAQAMAAALgFQALgGAGgKIAMAKQgJANgOAGQgNAGgQAAQgNAAgLgEgAArgJQAAgIgEgHQgDgHgFgFQgGgGgIgDQgHgDgJAAQgMAAgIAFQgJAFgFAHQgEAHgDAGIgCAJIBVAAIAAAAg");
	this.shape_1.setTransform(308.425,37.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgvA8IAAgKIBHhfIhEAAIAAgOIBZAAIAAAJIhGBgIBJAAIAAAOg");
	this.shape_2.setTransform(296.675,37.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHBaIAAh3IAPAAIAAB3gAgHhFQgEgDAAgFQAAgFAEgDQADgEAEAAQAFAAADAEQAEADAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_3.setTransform(289.075,34.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZA5QgMgGgIgMIAOgJQAFAJAJAFQAKAFAKAAIAKgBQAEgCAEgDIAHgGQACgFAAgFQABgIgGgEQgGgEgHgDIgQgEIgSgEQgHgDgGgHQgFgGAAgLQAAgJAEgHQAEgGAGgFQAFgEAHgCQAHgCAHAAQAPAAALAFQALAGAGAMIgPAIQgEgIgGgFQgHgEgLAAIgHABIgJAEQgDACgDAEQgCAEAAAEQAAAIAFAEQAGAEAHACIAQAEQAJACAIADQAJADAEAGQAGAHAAAMQAAAJgDAHQgEAHgGAFQgGAFgIACQgIACgJAAQgOAAgNgGg");
	this.shape_4.setTransform(281.2,37.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHBiIAAjDIAPAAIAADDg");
	this.shape_5.setTransform(268.075,33.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgHBiIAAjDIAPAAIAADDg");
	this.shape_6.setTransform(262.875,33.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWA9QgIgCgGgEQgGgEgEgHQgDgHgBgJQAAgOAIgIQAGgHALgEQAKgEALgBIAUgBIASAAIAAgIQAAgPgKgHQgJgHgOAAQgVAAgPAOIgJgLQAIgIANgFQAMgEAMAAQAVAAANAKQANALAAAWIAAAdIABAQIAAANIAAALIABAKIgOAAQgCgJAAgKIAAAAQgHAMgKAFQgKAFgOAAQgIAAgHgCgAgBABQgJABgIAEQgHADgFAFQgEAFAAAIQAAAFACAFIAHAHQADADAGABIAKABQALAAAIgDQAIgEAEgGQAGgGABgHQACgHAAgIIAAgIIgRAAg");
	this.shape_7.setTransform(253.9,37.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNBkIAAhpIgaAAIAAgOIAaAAIAAgoQgBgLAEgIQADgIAGgEQAEgFAGgCIANgCQAKAAAIADIgEAOQgFgDgIAAQgWAAAAAgIAAAiIAdAAIAAAOIgdAAIAABpg");
	this.shape_8.setTransform(239.3,33.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgYA7QgMgFgJgIQgIgJgFgLQgEgMAAgOQAAgNAEgLQAFgMAIgIQAJgJAMgEQALgFANAAQAOAAALAFQAMAEAIAJQAJAIAEAMQAFALAAANQAAAOgFAMQgEALgJAJQgIAIgMAFQgLAEgOAAQgNAAgLgEgAgTgsQgJAEgGAHQgGAGgDAJQgEAJAAAJQAAAKAEAJQADAJAGAHQAGAHAJADQAJAEAKAAQALAAAJgEQAJgDAGgHQAGgHADgJQAEgJAAgKQAAgJgEgJQgDgJgGgGQgGgHgJgEQgJgEgLAAQgKAAgJAEg");
	this.shape_9.setTransform(228.225,37.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZA5QgMgGgIgMIAOgJQAFAJAKAFQAJAFAKAAIAKgBQAEgCAEgDIAHgGQADgFgBgFQABgIgGgEQgGgEgHgDIgQgEIgSgEQgHgDgFgHQgGgGAAgLQAAgJAEgHQADgGAHgFQAFgEAHgCQAHgCAIAAQAOAAALAFQALAGAGAMIgPAIQgEgIgGgFQgHgEgKAAIgIABIgJAEQgDACgDAEQgCAEAAAEQAAAIAFAEQAGAEAHACIARAEQAJACAIADQAHADAFAGQAGAHAAAMQAAAJgDAHQgEAHgGAFQgGAFgIACQgIACgJAAQgOAAgNgGg");
	this.shape_10.setTransform(210,37.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAkA+IAAhGIgBgOQgBgHgDgFQgEgGgGgDQgFgDgKAAQgHAAgIACQgIAEgFAGQgGAGgDAJQgDAJAAAMIAAA8IgQAAIAAhWIAAgIIgBgJIAAgKIAAgGIAPAAIABANIAAAIIABAAQAFgKALgHQALgIANAAQAOAAAJAFQAJAEAFAHQAFAIACAJQACAJAAAKIAABHg");
	this.shape_11.setTransform(198.425,36.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgWA9QgIgCgGgEQgGgEgEgHQgDgHAAgJQgBgOAIgIQAGgHALgEQAKgEALgBIAUgBIASAAIAAgIQAAgPgKgHQgJgHgOAAQgUAAgRAOIgJgLQAJgIANgFQANgEALAAQAVAAANAKQANALAAAWIAAAdIABAQIAAANIAAALIABAKIgOAAQgCgJAAgKIAAAAQgHAMgKAFQgKAFgOAAQgIAAgHgCgAgBABQgKABgHAEQgIADgEAFQgEAFAAAIQAAAFADAFIAGAHQADADAGABIAKABQALAAAIgDQAIgEAEgGQAGgGABgHQACgHAAgIIAAgIIgRAAg");
	this.shape_12.setTransform(185.4,37.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgYA7QgMgFgJgIQgIgJgFgLQgEgMAAgOQAAgNAEgLQAFgMAIgIQAJgJAMgEQALgFANAAQAOAAALAFQAMAEAIAJQAJAIAEAMQAFALAAANQAAAOgFAMQgEALgJAJQgIAIgMAFQgLAEgOAAQgNAAgLgEgAgTgsQgJAEgGAHQgGAGgDAJQgEAJAAAJQAAAKAEAJQADAJAGAHQAGAHAJADQAJAEAKAAQALAAAJgEQAJgDAGgHQAGgHADgJQAEgJAAgKQAAgJgEgJQgDgJgGgGQgGgHgJgEQgJgEgLAAQgKAAgJAEg");
	this.shape_13.setTransform(172.125,37.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgHBiIAAjDIAPAAIAADDg");
	this.shape_14.setTransform(162.325,33.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAEBNQgFgDgEgEQgDgEgCgFQgCgGAAgHIAAhNIgaAAIAAgOIAaAAIAAgjIAPAAIAAAjIAiAAIAAAOIgiAAIAABNQAAAIAEAFQAFAEAIAAIAJgBIAIgDIACAOIgLADIgKABQgIAAgGgCg");
	this.shape_15.setTransform(408.625,7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAkA+IAAhGIgBgOQgBgHgDgFQgEgGgGgDQgFgDgKAAQgHAAgIACQgIAEgFAGQgGAGgDAJQgDAJAAAMIAAA8IgQAAIAAhWIAAgIIgBgJIAAgKIAAgGIAPAAIABANIAAAIIABAAQAFgKALgHQALgIANAAQAOAAAJAFQAJAEAFAHQAFAIACAJQACAJAAAKIAABHg");
	this.shape_16.setTransform(398.125,8.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgVA7QgMgFgIgIQgIgJgEgLQgEgMAAgOQAAgNAEgLQAFgLAIgJQAIgIALgFQALgFAMAAQAOAAAKAFQALAFAHAHQAHAIAEALQADAKAAAKIAAAKIhkAAIACANQACAHAFAIQAGAHAIAFQAJAFANAAQAMAAALgFQALgGAGgKIAMAKQgJANgOAGQgNAGgQAAQgNAAgLgEgAArgJQAAgIgEgHQgDgHgFgFQgGgGgIgDQgHgDgJAAQgMAAgIAFQgJAFgFAHQgEAHgDAGIgCAJIBVAAIAAAAg");
	this.shape_17.setTransform(384.725,8.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABLA+IAAhGIgBgOQgBgHgDgFQgEgGgGgDQgGgDgJAAQgLAAgHAEQgHAEgEAGQgEAGgCAHIgCAOIAABDIgOAAIAAhHQAAgRgGgKQgGgKgNAAQgJAAgHACQgIAEgGAGQgFAGgEAJQgDAJAAAMIAAA8IgPAAIAAhWIgBgIIAAgJIAAgKIgBgGIAQAAIABANIAAAIIABAAQAEgKAMgHQALgIAOAAQAMAAAKAHQAJAGAEAOQAGgOALgGQAMgHAMAAQAOAAAJAFQAJAEAEAHQAGAIACAJQACAJgBAKIAABHg");
	this.shape_18.setTransform(367.35,8.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgVA7QgMgFgIgIQgIgJgEgLQgEgMAAgOQAAgNAEgLQAFgLAIgJQAIgIALgFQALgFAMAAQAOAAAKAFQALAFAHAHQAHAIAEALQADAKAAAKIAAAKIhkAAIACANQACAHAFAIQAGAHAIAFQAJAFANAAQAMAAALgFQALgGAGgKIAMAKQgJANgOAGQgNAGgQAAQgNAAgLgEgAArgJQAAgIgEgHQgDgHgFgFQgGgGgIgDQgHgDgJAAQgMAAgIAFQgJAFgFAHQgEAHgDAGIgCAJIBVAAIAAAAg");
	this.shape_19.setTransform(350.125,8.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgGA8Igxh3IARAAIAnBmIAnhmIAQAAIgvB3g");
	this.shape_20.setTransform(337.925,8.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgYA7QgMgFgJgIQgIgJgFgLQgEgMAAgOQAAgNAEgLQAFgMAIgIQAJgJAMgEQALgFANAAQAOAAALAFQAMAEAIAJQAJAIAEAMQAFALAAANQAAAOgFAMQgEALgJAJQgIAIgMAFQgLAEgOAAQgNAAgLgEgAgTgsQgJAEgGAHQgGAGgDAJQgEAJAAAJQAAAKAEAJQADAJAGAHQAGAHAJADQAJAEAKAAQALAAAJgEQAJgDAGgHQAGgHADgJQAEgJAAgKQAAgJgEgJQgDgJgGgGQgGgHgJgEQgJgEgLAAQgKAAgJAEg");
	this.shape_21.setTransform(325.225,8.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgeA+IAAhWIAAgIIAAgJIAAgKIgBgGIAQAAIAAANIABAIQAFgLAJgHQAKgHANAAIAFABIAEABIgCAPIgGgBQgKAAgIADQgGAEgEAFQgFAGgDAIQgCAHAAAJIAABBg");
	this.shape_22.setTransform(315,8.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Ag/BbIAAiyIAQAAIAAAVIAAAAQAEgGAFgFQAGgEAGgDQAHgEAHgBIAMgCQAOAAAMAGQALAEAJAIQAIAJAFALQAFAMAAAOQAAAOgFAMQgFAKgIAIQgJAJgLAFQgMAEgOAAIgMgBQgHgCgHgDQgGgCgGgFQgFgFgEgGIAAAAIAABQgAgShIQgJAEgHAGQgHAHgEAJQgEAJAAAKQAAAKAEAJQAEAIAHAHQAHAGAJAEQAJAEAJAAQALAAAJgEQAJgEAGgGQAHgHADgIQADgJAAgKQAAgKgDgJQgDgJgHgHQgGgGgJgEQgJgEgLAAQgJAAgJAEg");
	this.shape_23.setTransform(303.125,11.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("ABLA+IAAhGIgBgOQgCgHgDgFQgDgGgGgDQgGgDgJAAQgLAAgHAEQgHAEgEAGQgEAGgCAHIgCAOIAABDIgOAAIAAhHQAAgRgGgKQgGgKgNAAQgIAAgJACQgHAEgFAGQgGAGgDAJQgEAJAAAMIAAA8IgPAAIAAhWIAAgIIgBgJIAAgKIgBgGIAQAAIAAANIABAIIABAAQAEgKALgHQALgIAPAAQAMAAAKAHQAJAGAEAOQAGgOALgGQALgHANAAQAOAAAJAFQAIAEAGAHQAFAIACAJQACAJAAAKIAABHg");
	this.shape_24.setTransform(284.85,8.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgHBaIAAh3IAPAAIAAB3gAgHhFQgEgDAAgFQAAgFAEgDQADgEAEAAQAFAAADAEQAEADAAAFQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_25.setTransform(271.775,5.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgVA7QgMgFgIgIQgIgJgEgLQgEgMAAgOQAAgNAEgLQAFgLAIgJQAIgIALgFQALgFAMAAQAOAAAKAFQALAFAHAHQAHAIAEALQADAKAAAKIAAAKIhkAAIACANQACAHAFAIQAGAHAIAFQAJAFANAAQAMAAALgFQALgGAGgKIAMAKQgJANgOAGQgNAGgQAAQgNAAgLgEgAArgJQAAgIgEgHQgDgHgFgFQgGgGgIgDQgHgDgJAAQgMAAgIAFQgJAFgFAHQgEAHgDAGIgCAJIBVAAIAAAAg");
	this.shape_26.setTransform(256.675,8.575);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("ABLA+IAAhGIgBgOQgCgHgDgFQgDgGgGgDQgFgDgKAAQgLAAgHAEQgHAEgEAGQgEAGgCAHIgCAOIAABDIgOAAIAAhHQAAgRgGgKQgGgKgNAAQgIAAgJACQgHAEgFAGQgGAGgDAJQgEAJAAAMIAAA8IgPAAIAAhWIgBgIIAAgJIAAgKIgBgGIAQAAIAAANIABAIIABAAQAEgKAMgHQALgIAOAAQAMAAAKAHQAJAGAEAOQAGgOALgGQAMgHAMAAQAOAAAJAFQAJAEAEAHQAGAIACAJQABAJAAAKIAABHg");
	this.shape_27.setTransform(239.3,8.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgYA7QgMgFgJgIQgIgJgFgLQgEgMAAgOQAAgNAEgLQAFgMAIgIQAJgJAMgEQALgFANAAQAOAAALAFQAMAEAIAJQAJAIAEAMQAFALAAANQAAAOgFAMQgEALgJAJQgIAIgMAFQgLAEgOAAQgNAAgLgEgAgTgsQgJAEgGAHQgGAGgDAJQgEAJAAAJQAAAKAEAJQADAJAGAHQAGAHAJADQAJAEAKAAQALAAAJgEQAJgDAGgHQAGgHADgJQAEgJAAgKQAAgJgEgJQgDgJgGgGQgGgHgJgEQgJgEgLAAQgKAAgJAEg");
	this.shape_28.setTransform(221.625,8.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAjBiIAAhGIgBgPQgBgHgDgFQgDgEgGgEQgGgDgJAAQgIAAgIADQgHADgGAFQgGAGgDAJQgDAKAAAMIAAA8IgPAAIAAjDIAPAAIAABhIAAAAQAFgKALgHQALgHAOAAQAOAAAIAEQAJAFAFAHQAFAHACAIQACAKAAAKIAABHg");
	this.shape_29.setTransform(207.7,4.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgdA+IAAhWIgBgIIAAgJIAAgKIgBgGIAPAAIABANIAAAIQAHgLAIgHQAJgHAOAAIAEABIAFABIgCAPIgGgBQgKAAgHADQgHAEgFAFQgFAGgCAIQgCAHAAAJIAABBg");
	this.shape_30.setTransform(192.2,8.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgYA7QgMgFgJgIQgIgJgFgLQgEgMAAgOQAAgNAEgLQAFgMAIgIQAJgJAMgEQALgFANAAQAOAAALAFQAMAEAIAJQAJAIAEAMQAFALAAANQAAAOgFAMQgEALgJAJQgIAIgMAFQgLAEgOAAQgNAAgLgEgAgTgsQgJAEgGAHQgGAGgDAJQgEAJAAAJQAAAKAEAJQADAJAGAHQAGAHAJADQAJAEAKAAQALAAAJgEQAJgDAGgHQAGgHADgJQAEgJAAgKQAAgJgEgJQgDgJgGgGQgGgHgJgEQgJgEgLAAQgKAAgJAEg");
	this.shape_31.setTransform(180.375,8.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Ag2BcIAAi3IBtAAIAAAPIhcAAIAABCIBVAAIAAAOIhVAAIAABYg");
	this.shape_32.setTransform(167.25,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.loans_mc, new cjs.Rectangle(0,-13.4,420,68), null);


(lib.let11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AgrBGQgLgGgGgJQgFgJgCgNQgCgMAAgPIAAhQIAtAAIAABIIAAAMQABAHACAFQACAGAFAEQAEADAJAAQAIAAAFgDQAGgDACgFQADgFABgHIABgNIAAhJIAtAAIAACRIgrAAIAAgUIgBAAIgGAJIgJAHIgLAGQgHACgIAAQgSAAgKgFg");
	this.shape.setTransform(-0.075,-20.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let11, new cjs.Rectangle(-10.7,-45,21.4,45), null);


(lib.let10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AAZBLIAAhIIAAgMQgBgHgCgFQgCgGgFgDQgFgEgIAAQgIAAgFADQgGADgDAFQgDAGAAAGIgBANIAABJIgtAAIAAiRIArAAIAAAUIABAAIAGgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAFAGAJQAGAJACANQACANAAAOIAABQg");
	this.shape.setTransform(-0.075,-20.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let10, new cjs.Rectangle(-10.7,-45,21.4,45), null);


(lib.let9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AgkBuQgNgGgKgKQgJgKgFgOQgFgNAAgRQAAgPAEgOQAFgNAJgLQAIgLAMgGQANgHAPAAQANAAANAFQAMAEAIALIAAAAIAAhhIAtAAIAADiIgpAAIAAgTIgBAAIgHAHIgKAIIgNAFQgHACgHAAQgQAAgNgFgAgYAMQgJAKAAARQAAAQAJALQAKAKAQAAQARAAAJgKQAKgLAAgQQAAgRgKgKQgJgKgRAAQgQAAgKAKg");
	this.shape.setTransform(-0.575,-24.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let9, new cjs.Rectangle(-11.5,-45,23.1,45), null);


(lib.let7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AgeBHQgPgFgMgLQgKgJgHgPQgGgNAAgSQAAgQAGgPQAHgNAKgKQAMgLAPgFQAOgGAQAAQARAAAPAGQAOAFAMALQALAKAGANQAGAPAAAQQAAASgGANQgGAPgLAJQgMALgOAFQgPAGgRgBQgQABgOgGgAgagaQgJALAAAPQAAARAJAKQAKAKAQAAQARAAAJgKQAKgKAAgRQAAgPgKgLQgJgKgRAAQgQAAgKAKg");
	this.shape.setTransform(-0.1,-20.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let7, new cjs.Rectangle(-11.2,-45,22.5,45), null);


(lib.let6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AgrBqQgTgEgPgNIAZglQAKAJAMAFQALAFAOAAQAUAAAJgKQAKgKAAgQIAAgOIAAAAQgIALgMAEQgLAFgKAAQgQAAgNgGQgNgFgKgLQgJgKgFgMQgFgOAAgRQAAgOAEgOQAFgOAJgKQAIgLAMgGQANgHAPAAQAKAAAHACIAOAGIALAHIAHAIIABAAIAAgTIApAAIAACEQAAAqgVAVQgVAWgpAAQgUAAgTgFgAgMhDQgGADgFAFQgFAFgDAGQgCAHAAAHQAAAHACAHQADAGAFAFQAFAFAGADQAHACAHAAQAHAAAHgCQAGgDAFgFQAFgFADgGQADgHAAgHQAAgHgDgHQgDgGgFgFQgFgFgGgDQgHgDgHAAQgHAAgHADg");
	this.shape.setTransform(0.825,-16.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let6, new cjs.Rectangle(-10.1,-45,23.1,45), null);


(lib.let4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AAEBeQgIgCgIgGQgHgFgEgIQgEgJAAgMIAAhEIgdAAIAAgkIAdAAIAAgrIAsAAIAAArIAoAAIAAAkIgoAAIAAAwIABALIADAIQACAEAEACQAEACAIAAIAJgBQAGgBADgDIAAAmQgIADgIAAIgQABQgLAAgKgCg");
	this.shape.setTransform(-0.35,-22.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let4, new cjs.Rectangle(-8.2,-45,16.4,45), null);


(lib.let3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AAZByIAAhIIAAgNQgBgHgCgFQgCgGgFgDQgFgFgIAAQgIAAgFAEQgGADgDAFQgDAGAAAGIgBAOIAABJIgtAAIAAjjIAtAAIAABmIAAAAIAFgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAEAGAKQAGAJACAMQACAMAAAPIAABRg");
	this.shape.setTransform(-0.075,-24.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let3, new cjs.Rectangle(-10.7,-45,21.4,45), null);


(lib.let2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AgYBHQgPgFgLgLQgLgJgHgPQgGgNAAgSQAAgQAGgPQAHgNALgKQALgLAPgFQAOgGAQAAQAQAAAMAGQANAFAJALQAJAKAFANQAFAPAAAQIAAAPIhoAAQADAMAJAIQAJAIAMAAQALgBAIgFQAHgFAGgHIAgAXQgLAOgRAHQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAGQgEAEgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape.setTransform(-0.075,-20.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let2, new cjs.Rectangle(-10.7,-45,21.4,45), null);


(lib.let1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#071A7D").s().p("AgyBLIAAiRIAtAAIAAAXIAAAAQAGgNAKgHQAKgHAPAAIAIABIAHABIAAApIgJgCIgKgBQgNAAgHAEQgIADgEAHQgDAGgBAJIgBATIAAA9g");
	this.shape.setTransform(0.525,-20.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.let1, new cjs.Rectangle(-8.2,-45,16.4,45), null);


(lib.cta1_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9BYIAAiwIB3AAIAAAkIhQAAIAAAhIBLAAIAAAjIhLAAIAAAkIBUAAIAAAkg");
	this.shape.setTransform(65.25,-20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAYBYIgkhHIgTAAIAABHIgnAAIAAiwIBEAAQANAAAMADQANACAIAHQAKAGAFALQAFAJAAAQQAAATgKANQgJAMgTAEIAtBKgAgfgOIAXAAIAKAAQAGgBAFgCQAEgCAEgEQADgEAAgHQAAgHgDgEQgCgEgFgCIgJgDIgKgBIgaAAg");
	this.shape_1.setTransform(49.85,-20);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BYIAAiwIB4AAIAAAkIhQAAIAAAhIBLAAIAAAjIhLAAIAAAkIBUAAIAAAkg");
	this.shape_2.setTransform(33.55,-20);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAlBYIAAhMIhKAAIAABMIgnAAIAAiwIAnAAIAABDIBKAAIAAhDIAoAAIAACwg");
	this.shape_3.setTransform(16.05,-20);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAcBYIhHhTIAABTIgnAAIAAiwIAnAAIAABKIBEhKIAzAAIhOBTIBVBdg");
	this.shape_4.setTransform(-8.475,-20);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVBXQgSgHgNgMQgNgMgHgRQgHgSAAgVQAAgUAHgSQAHgRANgMQANgMASgGQARgHAUAAIAPABIAQAFQAIADAIAFQAHAFAFAHIgdAZQgGgIgJgDQgIgEgLAAQgLAAgIAEQgKAFgHAHQgGAIgEALQgEAKAAALQAAANAEAKQAEAKAGAIQAHAIAJADQAIAFALAAQAMAAAJgFQAJgFAGgJIAhAYQgMAQgRAIQgRAHgSAAQgUAAgRgGg");
	this.shape_5.setTransform(-26.725,-20);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSBYIAAiwIAlAAIAACwg");
	this.shape_6.setTransform(-39.2,-20);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2BYIAAiwIAmAAIAACMIBHAAIAAAkg");
	this.shape_7.setTransform(-48.55,-20);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgVBXQgSgHgNgMQgNgMgHgRQgHgSAAgVQAAgUAHgSQAHgRANgMQANgMASgGQARgHAUAAIAPABIAQAFQAIADAIAFQAHAFAFAHIgdAZQgGgIgJgDQgIgEgLAAQgLAAgIAEQgKAFgHAHQgGAIgEALQgEAKAAALQAAANAEAKQAEAKAGAIQAHAIAJADQAIAFALAAQAMAAAJgFQAJgFAGgJIAhAYQgMAQgRAIQgRAHgSAAQgUAAgRgGg");
	this.shape_8.setTransform(-64.075,-20);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta1_mc, new cjs.Rectangle(-74.9,-38.1,149.8,38.1), null);


(lib.copy1_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMCFQgHgDgEgEQgFgFgDgGQgCgHAAgHQAAgHACgGQADgGAFgFQAEgEAHgDQAGgDAGAAQAHAAAGADQAGADAFAEQAFAFACAGQADAGAAAHQAAAHgDAHQgCAGgFAFQgFAEgGADQgGACgHAAQgGAAgGgCgAgbAvIAAgRQAAgLADgIQADgHAHgGIASgRIAPgOIAKgMQADgGAAgGQAAgNgHgGQgIgHgLAAQgRAAgJAJQgJAKgBAOIg5gEQAEgnAZgVQAZgUAmAAQARAAAPAEQAPAFALAJQAMAJAGAOQAHAOAAASQAAAKgCAJQgCAJgGAIQgFAJgJAIIgWASQgIAHgDAGQgDAHAAAGIAAALg");
	this.shape.setTransform(191.025,-28.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeBYQgTgHgNgNQgOgMgHgRQgIgSAAgVQAAgUAIgSQAHgRAOgNQANgMATgHQASgHAUAAQATAAAQAHQAPAHALAMQALANAGARQAGASAAAUIAAASIiAAAQAEAPALAKQALAJAPAAQAOAAAJgGQAKgGAHgKIAnAdQgOARgUAJQgUAJgWAAQgUAAgSgGgAgNgzQgHAEgFAFQgFAEgDAGQgCAGgBAHIBJAAQAAgOgKgKQgJgKgPAAQgJAAgHACg");
	this.shape_1.setTransform(169.675,-24.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUBYQgTgHgNgNQgOgMgHgRQgIgSAAgVQAAgUAIgSQAHgRAOgNQANgMATgHQASgHAUAAQAQABARAFQASAGANANIgkAmQgFgGgHgEQgIgDgIAAQgUAAgMAMQgLANAAATQAAAVALAMQAMANAUAAQAJAAAHgFQAGgEAGgFIAkAnQgNANgSAFQgRAGgQgBQgUAAgSgGg");
	this.shape_2.setTransform(150.85,-24.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaCGIAAizIA2AAIAACzgAgWhOQgJgKAAgNQAAgNAJgKQAKgJAMAAQANAAAKAJQAJAKAAANQAAANgJAKQgKAJgNAAQgMAAgKgJg");
	this.shape_3.setTransform(136.45,-28.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggCOIAAiHIglAAIAAgsIAlAAIAAggQAAgPADgNQACgNAIgJQAHgLANgFQAOgGAWAAIARAAIAQADIgDAvIgIgDIgKgBQgNAAgHAGQgGAGAAASIAAAcIApAAIAAAsIgpAAIAACHg");
	this.shape_4.setTransform(125.175,-29.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggCOIAAiHIglAAIAAgsIAlAAIAAggQAAgPADgNQACgNAIgJQAHgLANgFQAOgGAWAAIARAAIAQADIgDAvIgIgDIgKgBQgNAAgHAGQgGAGAAASIAAAcIApAAIAAAsIgpAAIAACHg");
	this.shape_5.setTransform(112.175,-29.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgmBYQgSgHgOgNQgNgMgIgRQgIgSAAgVQAAgUAIgSQAIgRANgNQAOgMASgHQASgHAUAAQAVAAASAHQASAHANAMQAOANAIARQAIASAAAUQAAAVgIASQgIARgOAMQgNANgSAHQgSAGgVAAQgUAAgSgGgAggggQgMANAAATQAAAVAMAMQAMANAUAAQAVAAAMgNQALgMAAgVQAAgTgLgNQgMgMgVAAQgUAAgMAMg");
	this.shape_6.setTransform(93.75,-24.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgeBYQgTgHgNgNQgOgMgHgRQgIgSAAgVQAAgUAIgSQAHgRAOgNQANgMATgHQASgHAUAAQATAAAQAHQAPAHALAMQALANAGARQAGASAAAUIAAASIiAAAQAEAPALAKQALAJAPAAQAOAAAJgGQAKgGAHgKIAnAdQgOARgUAJQgUAJgWAAQgUAAgSgGgAgNgzQgHAEgFAFQgFAEgDAGQgCAGgBAHIBJAAQAAgOgKgKQgJgKgPAAQgJAAgHACg");
	this.shape_7.setTransform(60.925,-24.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ABWBcIAAhoQAAgMgGgJQgFgJgNAAQgKAAgHADQgGADgEAGQgEAFgCAIIgCAPIAABeIg2AAIAAheIAAgMIgCgNQgDgGgFgFQgFgEgKAAQgLAAgGAEQgHAEgDAGQgEAHgBAIIgBAQIAABZIg4AAIAAizIA2AAIAAAZIAAAAIAIgLIALgJIAPgGQAJgDAKAAQATAAAPAIQAOAIAGAQQAKgRAOgIQANgHAVAAQASAAAMAGQAMAGAHALQAIAKADAOQADAPABAQIAABpg");
	this.shape_8.setTransform(34.25,-24.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgmBYQgSgHgOgNQgNgMgIgRQgIgSAAgVQAAgUAIgSQAIgRANgNQAOgMASgHQASgHAUAAQAVAAASAHQASAHANAMQAOANAIARQAIASAAAUQAAAVgIASQgIARgOAMQgNANgSAHQgSAGgVAAQgUAAgSgGgAggggQgMANAAATQAAAVAMAMQAMANAUAAQAVAAAMgNQALgMAAgVQAAgTgLgNQgMgMgVAAQgUAAgMAMg");
	this.shape_9.setTransform(6.9,-24.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAfCMIAAhYIAAgQQgBgJgDgHQgDgHgFgEQgGgFgLAAQgKAAgGAEQgHAEgDAHQgEAGgBAIIgBARIAABaIg4AAIAAkXIA4AAIAAB8IABAAQABgFAFgFIALgJQAGgEAHgDQAJgDAKAAQAVAAANAHQANAGAHAMQAHALADAPQADAPAAATIAABjg");
	this.shape_10.setTransform(-14.975,-29.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AguBbQgLgEgJgGQgJgIgFgKQgFgLgBgNQAAgQAHgLQAFgKAKgGQAKgHANgEQAMgEAOgCIAagCIAZgBQAAgOgLgJQgLgJgOAAQgNABgLAFQgMAGgIAKIgegfQAQgOAUgHQAVgIAVAAQAYABARAGQAPAGAKAMQAJALAEASQAEARgBAXIAABaIgyAAIAAgXIgCAAQgIAPgQAGQgOAGgRAAQgNABgMgEgAAGAMIgRADQgJADgGAEQgGAGAAAJQAAAKAJAFQAIAFAKAAQAGAAAIgCQAIgDAFgEQAGgEAEgGQAEgHAAgIIAAgMIgPAAg");
	this.shape_11.setTransform(-46.7,-24.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgmBYQgSgHgOgNQgNgMgIgRQgIgSAAgVQAAgUAIgSQAIgRANgNQAOgMASgHQASgHAUAAQAVAAASAHQASAHANAMQAOANAIARQAIASAAAUQAAAVgIASQgIARgOAMQgNANgSAHQgSAGgVAAQgUAAgSgGgAggggQgMANAAATQAAAVAMAMQAMANAUAAQAVAAAMgNQALgMAAgVQAAgTgLgNQgMgMgVAAQgUAAgMAMg");
	this.shape_12.setTransform(-78.6,-24.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAFB0QgLgDgIgHQgKgGgEgLQgFgKAAgPIAAhUIgkAAIAAgtIAkAAIAAg1IA2AAIAAA1IAxAAIAAAtIgxAAIAAA7IABANQAAAGADAFQADAEAFADQAFACAKAAIALgBQAHgBAEgDIAAAuQgJADgKACIgUABQgOAAgMgDg");
	this.shape_13.setTransform(-97.75,-26.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAfBcIAAhYIAAgPQgBgIgDgHQgDgHgFgFQgGgEgLAAQgKAAgGAEQgHAEgDAGQgEAHgBAIIgBAQIAABZIg4AAIAAizIA2AAIAAAZIAAAAIAIgLIALgJIAOgGQAJgDAKAAQAVAAANAGQANAHAHALQAHAMADAPQADAQAAASIAABig");
	this.shape_14.setTransform(-115.525,-24.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgbCGIAAizIA3AAIAACzgAgWhOQgJgKAAgNQAAgNAJgKQAKgJAMAAQANAAAKAJQAJAKAAANQAAANgJAKQgKAJgNAAQgMAAgKgJg");
	this.shape_15.setTransform(-130.95,-28.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAfBcIAAhYIAAgPQgBgIgDgHQgDgHgFgFQgGgEgLAAQgKAAgGAEQgHAEgDAGQgEAHgBAIIgBAQIAABZIg4AAIAAizIA2AAIAAAZIAAAAIAIgLIALgJIAOgGQAJgDAKAAQAVAAANAGQANAHAHALQAHAMADAPQADAQAAASIAABig");
	this.shape_16.setTransform(-157.275,-24.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag+BcIAAizIA3AAIAAAdIABAAQAIgQAMgJQAMgIATAAIAKAAIAIACIAAAzIgLgDIgMgBQgQAAgJAEQgKAFgFAIQgEAIgBALIgCAXIAABLg");
	this.shape_17.setTransform(-175.325,-24.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag1BWQgNgHgIgLQgHgMgCgPQgDgQAAgSIAAhiIA4AAIAABYIAAAPQABAIADAHQADAHAFAFQAGAEALAAQAJAAAHgDQAHgEADgHQAEgGABgJIABgQIAAhZIA4AAIAACzIg2AAIAAgZIAAAAIgIALIgLAJIgOAHQgJACgKAAQgVAAgNgGg");
	this.shape_18.setTransform(-194.175,-24.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAFB0QgLgDgJgHQgJgGgEgLQgFgKAAgPIAAhUIgkAAIAAgtIAkAAIAAg1IA2AAIAAA1IAxAAIAAAtIgxAAIAAA7IABANQAAAGAEAFQACAEAFADQAFACAJAAIAMgBQAHgBAEgDIAAAuQgJADgKACIgUABQgOAAgMgDg");
	this.shape_19.setTransform(-212.65,-26.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ABWBcIAAhoQAAgMgFgJQgGgJgOAAQgJAAgGADQgHADgEAGQgEAFgBAIIgCAPIAABeIg3AAIAAheIAAgMIgDgNQgCgGgFgFQgFgEgJAAQgLAAgHAEQgHAEgDAGQgDAHgCAIIgBAQIAABZIg3AAIAAizIA1AAIAAAZIABAAIAHgLIAMgJIAPgGQAIgDAKAAQATAAAOAIQAPAIAHAQQAKgRANgIQAOgHATAAQATAAAMAGQAMAGAIALQAHAKADAOQAEAPgBAQIAABpg");
	this.shape_20.setTransform(110.35,-62.325);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhgB/IAHgtQANAGANAAQAJAAAGgDQAGgCAEgDIAHgJIAFgOIAEgKIhPi1IA8AAIAuB3IAAAAIAoh3IA5AAIhSDRIgKAZQgFALgHAIQgIAHgNAEQgMAFgUAAQgVAAgUgIg");
	this.shape_21.setTransform(83.975,-57.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag1CDQgXgFgUgQIAfguQANALAOAGQAOAHARAAQAZAAAMgNQAMgMAAgTIAAgSIgBAAQgJANgOAGQgPAFgLAAQgUAAgRgHQgQgHgMgMQgLgNgHgQQgGgRAAgUQAAgSAGgRQAGgRAKgNQALgNAPgIQAPgIATAAQAMAAAJADIARAHIAOAJIAJAKIAAAAIAAgYIA0AAIAACkQAAAzgaAaQgaAbgzAAQgYAAgYgGgAgPhTQgHAEgGAGQgHAGgDAIQgDAIAAAJQAAAJADAHQADAIAHAHQAGAGAHADQAIADAJAAQAJAAAJgDQAIgDAGgGQAGgHADgIQADgHAAgJQAAgJgDgIQgDgIgGgGQgGgGgIgEQgJgEgJAAQgJAAgIAEg");
	this.shape_22.setTransform(61.475,-57.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgeBYQgTgHgNgNQgOgLgHgSQgIgRAAgWQAAgVAIgRQAHgRAOgMQANgNATgGQASgIAUAAQATAAAQAIQAPAGALANQALAMAGARQAGARAAAVIAAARIiAAAQAEARALAJQALAJAPAAQAOAAAJgGQAKgGAHgJIAnAcQgOARgUAJQgUAJgWAAQgUAAgSgGgAgNgyQgHACgFAGQgFAEgDAGQgCAGgBAHIBJAAQAAgOgKgKQgJgLgPAAQgJABgHADg");
	this.shape_23.setTransform(28.875,-62.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("ABWBcIAAhoQAAgMgFgJQgGgJgNAAQgKAAgHADQgGADgEAGQgEAFgCAIIgCAPIAABeIg2AAIAAheIAAgMIgCgNQgDgGgFgFQgFgEgKAAQgLAAgGAEQgHAEgDAGQgEAHgBAIIgBAQIAABZIg4AAIAAizIA2AAIAAAZIAAAAIAIgLIALgJIAPgGQAJgDAKAAQATAAAPAIQAOAIAGAQQAKgRAOgIQANgHAVAAQASAAAMAGQANAGAGALQAIAKADAOQAEAPAAAQIAABpg");
	this.shape_24.setTransform(2.2,-62.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgmBYQgSgHgOgNQgNgLgIgSQgIgRAAgWQAAgVAIgRQAIgRANgMQAOgNASgGQASgIAUAAQAVAAASAIQASAGAOANQANAMAIARQAIARAAAVQAAAWgIARQgIASgNALQgOANgSAHQgSAGgVAAQgUAAgSgGgAggggQgMANAAATQAAAVAMAMQAMANAUAAQAVAAAMgNQALgMAAgVQAAgTgLgNQgMgNgVAAQgUAAgMANg");
	this.shape_25.setTransform(-25.15,-62.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAfCMIAAhYIAAgQQgBgJgDgHQgDgHgFgEQgGgFgLAAQgKAAgGAEQgHAEgDAHQgEAGgBAIIgBARIAABaIg4AAIAAkXIA4AAIAAB8IABAAQABgFAFgFIALgJQAGgEAHgDQAJgDAKAAQAVAAANAHQANAGAHAMQAHALADAPQADAPAAATIAABjg");
	this.shape_26.setTransform(-47.025,-67.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Ag+BcIAAizIA3AAIAAAdIABAAQAIgQAMgJQAMgIATAAIAKAAIAIACIAAAzIgLgDIgMgBQgQAAgJAEQgKAFgFAIQgEAIgBALIgCAXIAABLg");
	this.shape_27.setTransform(-75.375,-62.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag1BWQgNgHgIgLQgHgMgCgPQgDgQAAgSIAAhiIA4AAIAABYIAAAPQABAIADAHQADAHAFAFQAGAEALAAQAJAAAHgDQAHgEADgHQAEgGABgJIABgQIAAhZIA4AAIAACzIg2AAIAAgZIAAAAIgIALIgLAJIgOAHQgJACgKAAQgVAAgNgGg");
	this.shape_28.setTransform(-94.225,-61.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgmBYQgTgHgNgNQgOgLgHgSQgIgRAAgWQAAgVAIgRQAHgRAOgMQANgNATgGQASgIAUAAQAVAAASAIQASAGANANQAPAMAHARQAIARAAAVQAAAWgIARQgHASgPALQgNANgSAHQgSAGgVAAQgUAAgSgGgAggggQgMANABATQgBAVAMAMQAMANAUAAQAVAAALgNQAMgMAAgVQAAgTgMgNQgLgNgVAAQgUAAgMANg");
	this.shape_29.setTransform(-116.1,-62.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AhgB/IAHgtQANAGANAAQAJAAAGgDQAGgCAEgDIAHgJIAFgOIAEgKIhPi1IA8AAIAuB3IAAAAIAoh3IA5AAIhSDRIgKAZQgFALgHAIQgIAHgNAEQgMAFgUAAQgVAAgUgIg");
	this.shape_30.setTransform(-137.675,-57.65);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgtCHQgQgGgMgNQgLgMgHgSQgGgRAAgUQAAgTAGgRQAGgQAKgNQALgOAPgIQAPgIATAAQARAAAPAFQAPAGAJANIABAAIAAh3IA4AAIAAEWIg0AAIAAgXIAAAAIgJAJIgMAJIgRAHQgIADgIAAQgUAAgRgHgAgeAOQgLAOAAATQAAAVALANQAMAMAUAAQAVAAAMgMQALgNAAgVQAAgTgLgOQgMgMgVAAQgUAAgMAMg");
	this.shape_31.setTransform(-171.125,-66.85);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgaCGIAAizIA2AAIAACzgAgWhOQgJgKAAgNQAAgNAJgKQAKgJAMAAQANAAAKAJQAJAKAAANQAAANgJAKQgKAJgNAAQgMAAgKgJg");
	this.shape_32.setTransform(-187,-66.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Ah4CDIAAkFIBXAAQAfAAAbAHQAdAHAVAQQAVAPANAZQAMAaAAAiQAAAggMAYQgMAZgVARQgUAQgaAJQgbAIgcAAgAg+BOIAeAAQAUgBAQgEQARgDANgKQAMgJAIgPQAHgQAAgVQAAgTgHgPQgIgOgMgJQgMgJgRgFQgPgFgSAAIgiAAg");
	this.shape_33.setTransform(-205.1,-66.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy1_mc, new cjs.Rectangle(-221.8,-92.1,443.70000000000005,92.1), null);


(lib.bg3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg3();
	this.instance.setTransform(-485,-249.95,0.5,0.4999);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg3_1, new cjs.Rectangle(-485,-249.9,970,249.9), null);


(lib.bg2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0A1482").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape.setTransform(0,-125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg2, new cjs.Rectangle(-485,-250,970,250), null);


(lib.bg_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E9BFF").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_mc, new cjs.Rectangle(0,0,970,250), null);


(lib.text_anim_mc_complete = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// let13
	this.instance = new lib.let1();
	this.instance.setTransform(120,-37.1,1,1,24.9446,0,0,-4.7,-13.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// let12
	this.instance_1 = new lib.let7();
	this.instance_1.setTransform(133.7,-27.1,0.9999,0.9999,55.0974,0,0,0.1,-12.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// let11
	this.instance_2 = new lib.let11();
	this.instance_2.setTransform(138.85,-13.25,1,1,82.2995,0,0,-0.2,-12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// let10
	this.instance_3 = new lib.let10();
	this.instance_3.setTransform(136.75,0.8,0.9999,0.9999,117.1004,0,0,-0.6,-13.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// let9
	this.instance_4 = new lib.let9();
	this.instance_4.setTransform(125.75,10.7,0.9999,0.9999,149.9959,0,0,-1.1,-12.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// let8
	this.instance_5 = new lib.let4();
	this.instance_5.setTransform(103.6,14.8,0.9999,0.9999,179.8557,0,0,0.7,-12.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// let7
	this.instance_6 = new lib.let7();
	this.instance_6.setTransform(89.05,14.9,0.9999,0.9999,178.4146,0,0,0.1,-12.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// let6
	this.instance_7 = new lib.let6();
	this.instance_7.setTransform(72.55,14.85,0.9999,0.9999,-178.6403,0,0,0,-12.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// let5
	this.instance_8 = new lib.let2();
	this.instance_8.setTransform(53.65,15.35,1,1,-179.7657,0,0,0.1,-13.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// let4
	this.instance_9 = new lib.let4();
	this.instance_9.setTransform(38.6,14.8,0.9999,0.9999,179.8557,0,0,0.7,-12.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// let3
	this.instance_10 = new lib.let3();
	this.instance_10.setTransform(24.55,15.2,0.9999,0.9999,179.1965,0,0,0,-13.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

	// let2
	this.instance_11 = new lib.let2();
	this.instance_11.setTransform(7.55,15.45,1,1,-179.7657,0,0,0.1,-13.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1));

	// let1
	this.instance_12 = new lib.let1();
	this.instance_12.setTransform(-2.95,15.6,0.9999,0.9999,-179.1414,0,0,-4.8,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(1));

	// txt_Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzgG3IAAttMAnBAAAIAANtg");
	mask.setTransform(-6.175,-17.125);

	// txt
	this.instance_13 = new lib.text_anim();
	this.instance_13.setTransform(100.05,-48.45,1,1,0,0,0,233.3,21.1);

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_anim_mc_complete, new cjs.Rectangle(-135,-72,310.1,122.2), null);


(lib.text_anim_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_30 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(30).call(this.frame_30).wait(1));

	// let13
	this.instance = new lib.let1();
	this.instance.setTransform(94.9,-47.25,1,1,0,0,0,0,-22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(28).to({_off:false},0).wait(1).to({x:110.25,y:-47},0).wait(1).to({regX:-4.7,regY:-13.1,rotation:24.9446,x:120,y:-37.1},0).wait(1));

	// let12
	this.instance_1 = new lib.let7();
	this.instance_1.setTransform(93.6,-37.3,1,1,0,0,0,0,-12.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(27).to({_off:false},0).wait(1).to({x:109.1,y:-37.2},0).wait(1).to({regX:0.1,regY:-12.7,rotation:28.4187,x:122.8,y:-36.15},0).wait(1).to({regY:-12.8,scaleX:0.9999,scaleY:0.9999,rotation:55.0974,x:133.7,y:-27.1},0).wait(1));

	// let11
	this.instance_2 = new lib.let11();
	this.instance_2.setTransform(95.6,-47.2,1,1,0,0,0,0,-22.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(26).to({_off:false},0).wait(1).to({x:111.1},0).wait(1).to({regX:-0.1,regY:-12.4,rotation:29.9992,x:122.1,y:-35.3},0).wait(1).to({rotation:59.9984,x:133.15,y:-29.05},0).wait(1).to({regX:-0.2,regY:-12.5,rotation:82.2995,x:138.85,y:-13.25},0).wait(1));

	// let10
	this.instance_3 = new lib.let10();
	this.instance_3.setTransform(96.95,-47.25,1,1,0,0,0,0,-22.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(25).to({_off:false},0).wait(1).to({x:112.4},0).wait(1).to({regX:-0.8,regY:-13.2,rotation:25.7021,x:126.15,y:-34.7},0).wait(1).to({regX:-0.7,rotation:45.9373,x:134.5,y:-26.9},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:81.3941,x:139.3,y:-13.3},0).wait(1).to({regX:-0.6,regY:-13.4,rotation:117.1004,x:136.75,y:0.8},0).wait(1));

	// let9
	this.instance_4 = new lib.let9();
	this.instance_4.setTransform(98.05,-37.1,1,1,0,0,0,-1.1,-12.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({_off:false},0).wait(1).to({x:113.45,y:-36.9},0).wait(1).to({rotation:45,x:122.65,y:-34.95},0).wait(1).to({regX:-1,rotation:59.9984,x:134.35,y:-22.55},0).wait(1).to({rotation:89.9983,x:139,y:-15},0).wait(1).to({regX:-1.1,regY:-12.3,rotation:119.9973,x:135.05,y:-0.65},0).wait(1).to({regY:-12.2,scaleX:0.9999,scaleY:0.9999,rotation:149.9959,x:125.75,y:10.7},0).wait(1));

	// let8
	this.instance_5 = new lib.let4();
	this.instance_5.setTransform(108.05,-37.7,1,1,0,0,0,0.5,-12.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(23).to({_off:false},0).wait(1).to({regX:0.6,rotation:31.7489,x:122.4,y:-35.95},0).wait(1).to({regX:0.7,scaleX:0.9999,scaleY:0.9999,rotation:61.8942,x:132.65,y:-28.85},0).wait(1).to({rotation:83.6333,x:138.8,y:-13.2},0).wait(1).to({regY:-12.7,rotation:117.3475,x:136.2,y:0.35},0).wait(1).to({rotation:147.3479,x:125.75,y:11.4},0).wait(1).to({regY:-12.8,rotation:179.8557,x:117.2,y:14.8},0).wait(1).to({x:103.6},0).wait(1));

	// let7
	this.instance_6 = new lib.let7();
	this.instance_6.setTransform(106.85,-37.6,1,1,0,0,0,0,-12.6);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(22).to({_off:false},0).wait(1).to({regX:0.1,rotation:34.4665,x:117.95,y:-38.45},0).wait(1).to({rotation:58.4176,x:133.35,y:-27.4},0).wait(1).to({rotation:88.4173,x:138.8,y:-13.6},0).wait(1).to({regY:-12.7,scaleX:0.9999,scaleY:0.9999,rotation:118.4156,x:136.9,y:-1.55},0).wait(1).to({regY:-12.8,rotation:148.415,x:130.95,y:7.75},0).wait(1).to({rotation:178.4146,x:119.05,y:14.9},0).to({x:89.05},2).wait(1));

	// let6
	this.instance_7 = new lib.let6();
	this.instance_7.setTransform(108.3,-37.5,1,1,0,0,0,0,-12.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(21).to({_off:false},0).wait(1).to({regX:0.1,rotation:29.9992,x:121.4,y:-35.3},0).wait(1).to({rotation:59.9984,x:132.55,y:-28.05},0).wait(1).to({rotation:84.933,x:138.55,y:-13.4},0).wait(1).to({regY:-12.6,scaleX:0.9999,scaleY:0.9999,rotation:110.6739,x:136,y:0.5},0).wait(1).to({rotation:131.8739,x:126.8,y:9.25},0).wait(1).to({regX:0,rotation:181.3597,x:118.35,y:14.85},0).to({x:72.55},3).wait(1));

	// let5
	this.instance_8 = new lib.let2();
	this.instance_8.setTransform(111.9,-38.1,1,1,0,0,0,0,-12.9);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(20).to({_off:false},0).wait(1).to({regX:0.1,rotation:29.9992,x:125.8,y:-34.6},0).wait(1).to({regY:-13,rotation:59.9984,x:133.2,y:-27.85},0).wait(1).to({regY:-13.1,rotation:89.9983,x:139.55,y:-13.65},0).wait(1).to({regX:0.2,rotation:119.9973,x:136.15,y:0.65},0).wait(1).to({regY:-13.2,scaleX:0.9999,scaleY:0.9999,rotation:142.2377,x:126.05,y:12.7},0).wait(1).to({regX:0.1,scaleX:1,scaleY:1,rotation:180.2343,x:115.75,y:15.45},0).to({x:53.65,y:15.35},4).wait(1));

	// let4
	this.instance_9 = new lib.let4();
	this.instance_9.setTransform(111.3,-37.7,1,1,0,0,0,0.5,-12.6);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(19).to({_off:false},0).wait(1).to({regX:0.6,rotation:31.7489,x:122.4,y:-35.95},0).wait(1).to({regX:0.7,scaleX:0.9999,scaleY:0.9999,rotation:61.8942,x:135.65,y:-26.85},0).wait(1).to({rotation:83.6333,x:138.8,y:-13.2},0).wait(1).to({regY:-12.7,rotation:117.3475,x:136.2,y:0.35},0).wait(1).to({rotation:147.3479,x:125.75,y:11.4},0).wait(1).to({regY:-12.8,rotation:179.8557,x:117.2,y:14.8},0).to({x:38.6},5).wait(1));

	// let3
	this.instance_10 = new lib.let3();
	this.instance_10.setTransform(109.75,-38.2,1,1,0,0,0,0,-13.1);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(18).to({_off:false},0).wait(1).to({rotation:29.9992,x:122.55,y:-34.6},0).wait(1).to({regX:0.1,regY:-13.2,rotation:51.2129,x:134.25,y:-26.75},0).wait(1).to({rotation:81.2121,x:139.25,y:-12.75},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:119.1967,x:136.5,y:1},0).wait(1).to({rotation:149.1968,x:125.25,y:12.4},0).wait(1).to({regX:0,rotation:179.1965,x:115.95,y:15.2},0).to({x:24.55},6).wait(1));

	// let2
	this.instance_11 = new lib.let2();
	this.instance_11.setTransform(111.1,-38.1,1,1,0,0,0,0,-12.9);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(17).to({_off:false},0).wait(1).to({regX:0.1,rotation:29.9992,x:125.8,y:-34.6},0).wait(1).to({regY:-13,rotation:59.9984,x:133.2,y:-27.85},0).wait(1).to({regY:-13.1,rotation:89.9983,x:139.55,y:-13.65},0).wait(1).to({regX:0.2,rotation:119.9973,x:136.15,y:0.65},0).wait(1).to({regY:-13.2,scaleX:0.9999,scaleY:0.9999,rotation:142.2377,x:125.65,y:13.1},0).wait(1).to({regX:0.1,scaleX:1,scaleY:1,rotation:180.2343,x:114.15,y:15.45},0).to({x:7.55},7).wait(1));

	// let1
	this.instance_12 = new lib.let1();
	this.instance_12.setTransform(110,-47.75,1,1,0,0,0,0,-22.5);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(16).to({_off:false},0).wait(1).to({regX:-4.7,regY:-13.1,rotation:24.9446,x:120,y:-37.1},0).wait(1).to({regY:-13.2,rotation:54.9437,x:131.1,y:-30.95},0).wait(1).to({regX:-4.6,rotation:81.1361,x:138.35,y:-16.25},0).wait(1).to({regY:-13.3,scaleX:0.9999,scaleY:0.9999,rotation:116.5729,x:137.4,y:-0.65},0).wait(1).to({regY:-13.4,rotation:146.5723,x:126.4,y:11.35},0).wait(1).to({regX:-4.7,regY:-13.5,rotation:176.5722,x:116.65,y:15.1},0).wait(1).to({regX:-4.8,rotation:180.8586,x:105.05,y:15.4},0).to({x:-2.95,y:15.6},7).wait(1));

	// txt_Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AzgG3IAAttMAnBAAAIAANtg");
	var mask_graphics_29 = new cjs.Graphics().p("AzgG3IAAttMAnBAAAIAANtg");
	var mask_graphics_30 = new cjs.Graphics().p("AzgG3IAAttMAnBAAAIAANtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-6.175,y:-17.125}).wait(29).to({graphics:mask_graphics_29,x:-8.775,y:-17.125}).wait(1).to({graphics:mask_graphics_30,x:-6.175,y:-17.125}).wait(1));

	// txt
	this.instance_13 = new lib.text_anim();
	this.instance_13.setTransform(-363.7,-49.9,1,1,0,0,0,233.3,21.1);

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:100.05,y:-48.45},30).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-72,310.1,122.2);


(lib.curve_rotate_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.instance = new lib.copy1_mc();
	this.instance.setTransform(-95.65,-51.75,1,1,0,0,0,0,-46.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.text_curve_anim = new lib.text_anim_mc_complete();
	this.text_curve_anim.name = "text_curve_anim";
	this.text_curve_anim.setTransform(-125.1,-77.35,1.0683,1.0683,0,0,0,-239.2,-22.2);

	this.timeline.addTween(cjs.Tween.get(this.text_curve_anim).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.curve_rotate_mc, new cjs.Rectangle(-317.5,-127.9,805.1,125), null);


// stage content:
(lib._970x250_home = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [289];
	// timeline functions:
	this.frame_289 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(289).call(this.frame_289).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("EhLngTXMCXPAAAMAAAAmvMiXPAAAg");
	this.shape.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(290));

	// tcs
	this.instance = new lib.tcs_mc();
	this.instance.setTransform(196.5,230.95,1,1,0,0,0,0,-8.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(265).to({_off:false},0).to({alpha:1},9).wait(16));

	// cta
	this.instance_1 = new lib.cta1_mc();
	this.instance_1.setTransform(263.95,152,1,1,0,0,0,0,-19.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(205).to({_off:false},0).to({x:283.95,alpha:1},10).wait(19).to({scaleX:1.1489,scaleY:1.1489,y:151.95},5).to({scaleX:1,scaleY:1,y:152},5).wait(11).to({scaleX:1.1489,scaleY:1.1489,y:151.95},5).to({scaleX:1,scaleY:1,y:152},5).wait(25));

	// loans
	this.instance_2 = new lib.loans_mc();
	this.instance_2.setTransform(315,110,1,1,0,0,0,284,23.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(205).to({_off:false},0).to({x:335,alpha:1},10).wait(75));

	// copyrerotate
	this.instance_3 = new lib.text_anim_mc_complete();
	this.instance_3.setTransform(350,48.4,1.0966,1.0966,0,0,0,-127,-58);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(205).to({_off:false},0).to({alpha:1},10).wait(75));

	// logo2
	this.instance_4 = new lib.logo2_mc();
	this.instance_4.setTransform(853,195.7,1,1,0,0,0,0,-39.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(216).to({_off:false},0).to({alpha:1},9).wait(65));

	// logo
	this.instance_5 = new lib.logo1_mc();
	this.instance_5.setTransform(854.5,198.7,1,1,0,0,0,0,-26.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(202).to({alpha:0},3).wait(85));

	// curve
	this.instance_6 = new lib.text_anim_mc();
	this.instance_6.setTransform(233.15,93.95,1.0683,1.0683,0,0,0,-239.2,-22.2);

	this.instance_7 = new lib.curve_rotate_mc("synched",0);
	this.instance_7.setTransform(358.25,106,1,1,0,0,0,0,-65.3);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},101).to({state:[{t:this.instance_7}]},59).to({state:[{t:this.instance_7}]},11).to({state:[{t:this.instance_7}]},31).to({state:[{t:this.instance_7}]},3).wait(85));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(160).to({_off:false},0).to({rotation:180,loop:false},11).wait(31).to({startPosition:0},0).to({alpha:0},3).wait(85));

	// copy1_MASK (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_4 = new cjs.Graphics().p("AldDIIAAmPIK7AAIAAGPg");
	var mask_graphics_7 = new cjs.Graphics().p("AgoDZIAAmxIMuAAIAAGxgAsFDAIAAmOIK8AAIAAGOg");
	var mask_graphics_10 = new cjs.Graphics().p("AppDZIAAmxIMvAAIAAGxgAEYDAIAAmOIQuAAIAAGOgA1FDAIAAmOIK8AAIAAGOg");
	var mask_graphics_13 = new cjs.Graphics().p("Av5DZIAAmxIMwAAIAAGxgAPZDIIAAkrIL9AAIAAErgAh3DAIAAmOIQtAAIAAGOgA7VDAIAAmOIK8AAIAAGOg");
	var mask_graphics_16 = new cjs.Graphics().p("A7VGVIAAsfIK8AAIAAGPIAgAAIAAmZIMwAAIAAGyIsPAAIAAF3gAPZANIAAksIL9AAIAAEsgAh3AFIAAmPIQtAAIAAGPg");
	var mask_graphics_19 = new cjs.Graphics().p("Av5GvIAAg0IrcAAIAAsfIK8AAIAAGQIAgAAIAAmaIMwAAIAAGDIACAAIAAHagAPZgNIAAksIL9AAIAAEsgAh3gUIAAmQIQtAAIAAGQg");
	var mask_graphics_22 = new cjs.Graphics().p("Av5GvIAAg0IrcAAIAAsfIK8AAIAAGQIAgAAIAAmaIMwAAIAAGDIACAAIAAHagAiVGUIAAlFIENAAIAAFFgAPZgNIAAksIL9AAIAAEsgAh3gUIAAmQIQtAAIAAGQg");
	var mask_graphics_25 = new cjs.Graphics().p("ACWGxIAAnHIkNAAIAAmPIQtAAIAAF0IAjAAIAAkJIL9AAIAAEsIohAAIAAG/gAv5GuIAAg0IrcAAIAAsfIK8AAIAAGPIAgAAIAAmZIMwAAIAAGDIACAAIAAHagAiVGTIAAlGIENAAIAAFGg");
	var mask_graphics_28 = new cjs.Graphics().p("AMDHHIAAgtIuYAAIAAnGIj5AAIAAmQIPaAAIAAF1IAfAAIAAkKIIwAAIAAhrIGQAAIAAFlIG6AAIAAIegA0IGXIAAg0IrcAAIAAsfIK8AAIAAGQIAgAAIAAmaIMwAAIAAGDIACAAIAAHagAmkF8IAAlFIEOAAIAAFFg");
	var mask_graphics_31 = new cjs.Graphics().p("AKCHHIAAgtIuYAAIAAnGIj5AAIAAmQIPaAAIAAF1IAfAAIAAkKIIwAAIAAhrIGQAAIAAFlIG6AAIAAArIECAAIAAGPIkCAAIAABkgA2JGXIAAg0IrcAAIAAsfIK8AAIAAGQIAgAAIAAmaIMwAAIAAGDIACAAIAAHagAolF8IAAlFIEOAAIAAFFg");
	var mask_graphics_101 = new cjs.Graphics().p("AKCHHIAAgtIuYAAIAAnGIj5AAIAAmQIPaAAIAAF1IAfAAIAAkKIIwAAIAAhrIGQAAIAAFlIG6AAIAAArIECAAIAAGPIkCAAIAABkgA2JGXIAAg0IrcAAIAAsfIK8AAIAAGQIAgAAIAAmaIMwAAIAAGDIACAAIAAHagAolF8IAAlFIEOAAIAAFFg");
	var mask_graphics_160 = new cjs.Graphics().p("AKCHHIAAgtIuYAAIAAnGIj5AAIAAmQIPaAAIAAF1IAfAAIAAkKIIwAAIAAhrIGQAAIAAFlIG6AAIAAArIECAAIAAGPIkCAAIAABkgA2JGXIAAg0IrcAAIAAsfIK8AAIAAGQIAgAAIAAmaIMwAAIAAGDIACAAIAAHagAolF8IAAlFIEOAAIAAFFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_4,x:75,y:100}).wait(3).to({graphics:mask_graphics_7,x:117.375,y:100.75}).wait(3).to({graphics:mask_graphics_10,x:175,y:100.75}).wait(3).to({graphics:mask_graphics_13,x:215,y:100.75}).wait(3).to({graphics:mask_graphics_16,x:215,y:119.5}).wait(3).to({graphics:mask_graphics_19,x:215,y:122.125}).wait(3).to({graphics:mask_graphics_22,x:215,y:122.125}).wait(3).to({graphics:mask_graphics_25,x:215,y:122.25}).wait(3).to({graphics:mask_graphics_28,x:242.1,y:124.5}).wait(3).to({graphics:mask_graphics_31,x:255,y:124.5}).wait(70).to({graphics:mask_graphics_101,x:255,y:124.5}).wait(59).to({graphics:mask_graphics_160,x:255,y:124.5}).wait(130));

	// copy1
	this.instance_8 = new lib.copy1_mc();
	this.instance_8.setTransform(262.6,119.55,1,1,0,0,0,0,-46.1);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(4).to({_off:false},0).wait(97).to({_off:true},59).wait(130));

	// bg3
	this.instance_9 = new lib.bg3_1();
	this.instance_9.setTransform(484.95,125,1,1.0002,0,0,0,0,-125);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(202).to({_off:false},0).to({alpha:1},3).wait(85));

	// bg2
	this.instance_10 = new lib.bg2();
	this.instance_10.setTransform(485,125,1,1,0,0,0,0,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(95).to({alpha:0},6).wait(189));

	// bg1
	this.instance_11 = new lib.bg_mc();
	this.instance_11.setTransform(485,125,1,1,0,0,0,485,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(290));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(336,-91.7,634,509.8);
// library properties:
lib.properties = {
	id: '9AEF9451ECD6457C8D70834B21F4BB98',
	width: 970,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/970x250_home_atlas_P_1.png", id:"970x250_home_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9AEF9451ECD6457C8D70834B21F4BB98'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;